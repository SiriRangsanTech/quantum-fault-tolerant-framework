# Maxwell's Equations from Zero Free Action

Maxwell's equations are not postulated in QLF — they emerge from the 8-twist ZFA algebra in the continuum limit. This document maps each equation to its combinatorial origin and provides machine-verified or numerically confirmed anchors for each claim.

See [Experimental_Consistency.md](Experimental_Consistency.md) for the full derivation with force law and energy accounting. See [maxwell_qlf.py](maxwell_qlf.py) for numerical confirmation.

---

## Field Identification

The 8-twist alphabet `{^, v, <, >, /, \, +, −}` decomposes into three spatial axis pairs and one gauge pair:

| Twist pair | Direction | Field component |
|---|---|---|
| `>` / `<` | x-axis | B_x, E_x |
| `^` / `v` | y-axis | B_y, E_y |
| `/` / `\` | z-axis | B_z, E_z |
| `+` / `−` | gauge (temporal) | charge density ρ |

For a history h, the discrete field components are:

```
B_x(h) = count(>) − count(<)    [right minus left]
B_y(h) = count(^) − count(v)    [up minus down]
B_z(h) = count(/) − count(\)    [slash minus bslash]

charge(h) = count(+) − count(−) [gauge imbalance = net charge]
```

The E-field is the transverse momentum exchange rate — defined via the time-sequence of ZFA events rather than a single event. In the continuum limit, E and B satisfy the wave equation with propagation speed c by construction (see [Experimental_Consistency.md §Wave Equation](Experimental_Consistency.md)).

The single-history `B(h)` definitions above are the *closure-level* projection of a broader structural reading: macroscopically, `B` is the spatial-gradient signature of the local vacuum's spin-orientation distribution. The spatial-dynamics reframe — like-spin pairs expanding space via Pauli exclusion, opposite-spin pairs contracting it via singlet annihilation, B-field as the directional gradient — is in [`Magnetism_Spatial_Dynamics.md`](Magnetism_Spatial_Dynamics.md).

**Charge conjugation = viewing from behind.** The signed gauge count `charge(h) = count(+) − count(−)` **negates** under the antiparticle map (conjugate-and-reverse) — a positron read from behind carries the electron's charge — machine-verified as `chiralCharge_conj` / `C_eq_motional_reversal` in [`Spin_QLF.md`](Spin_QLF.md) / [`lean/QLF_Spin.lean`](lean/QLF_Spin.lean), where charge co-negates with the perpendicular-spin chirality (the handedness *is* the charge). So the electric axis (`+−`) is spin's chiral component seen from the other side.

---

## Equation 1: ∇·B = 0 (No Magnetic Monopoles)

**ZFA origin:** `isZFAClosed` requires every individual twist count to be zero. Therefore B_x = B_y = B_z = 0 for any ZFA-closed event, and their divergence ∇·B = B_x + B_y + B_z vanishes identically.

**Machine-verified:** `no_magnetic_monopoles` — [lean/ZFAEventDynamics.lean](lean/ZFAEventDynamics.lean)

```lean
theorem no_magnetic_monopoles (e : ZFAEvent) : divB e.history = 0
```

Every ZFA-closed event has zero magnetic divergence. Magnetic monopoles are algebraically impossible — they would require an unbalanced spatial twist count, which `isZFAClosed` forbids by construction.

**Numerical confirmation:** `maxwell_qlf.py` Report 1 — `divB = 0` verified across 10,000 randomly generated ZFA-closed events.

---

## Equation 2: ∇·E = ρ/ε₀ (Gauss's Law for Electricity)

**ZFA origin:** The gauge pair `+`/`−` carries net charge. In the continuum limit, a local gauge imbalance `charge(h) = count(+) − count(−)` acts as a source for the transverse polarity field (E). The constant ε₀ emerges from the 8-fold twist orthogonality (see `constants_mapper.py`).

**Discrete statement:** For a history with gauge imbalance q, the divergence of the local E-field is proportional to q.

**Numerical confirmation:** `maxwell_qlf.py` Report 2 — E-field divergence tracks gauge imbalance with constant ratio ε₀.

---

## Equation 3: ∇×E = −∂B/∂t (Faraday's Law)

**ZFA origin:** Spatial twists propagate at speed c by construction (spatial free action vs. gauge/local directions). A changing population of spatial twist threads induces a curl in the transverse polarity image. The factor of −1 follows from Hermitian conjugation reversing orientation.

**Continuum limit argument:** As spatial imbalance changes across a surface, the boundary integral of E equals the negative rate of change of magnetic flux through that surface. This is the direct thread-counting analog of Faraday's law.

**Numerical confirmation:** `maxwell_qlf.py` Report 3 — 1D wave simulation shows curl(E) ≈ −∂B/∂t to within numerical precision.

---

## Equation 4: ∇×B = μ₀J + μ₀ε₀ ∂E/∂t (Ampère-Maxwell Law)

**ZFA origin:**
- The conduction current J is the net flow velocity of gauge-imbalanced threads.
- The displacement term arises from time-varying transverse polarity (changing E threads).
- The constants μ₀ and ε₀ satisfy c = 1/√(μ₀ε₀) automatically from the ZFA propagation speed.

**Numerical confirmation:** `maxwell_qlf.py` Report 4 — wave propagation speed matches c = 1/√(μ₀ε₀) to 4 significant figures.

---

## Lean Status

| Equation | Status | Lean anchor |
|---|---|---|
| ∇·B = 0 | **Machine-verified** | `no_magnetic_monopoles` — ZFAEventDynamics.lean |
| ∇·E = ρ/ε₀ | Provable (discrete form) | `gauss_electric` (discrete gauge-imbalance count) |
| ∇×E = −∂B/∂t | **Machine-verified (conservation form)** | `faraday_integral` / `faraday_closed_cycle` — QLF_MaxwellCurl.lean |
| ∇×B = μ₀J + μ₀ε₀∂E/∂t | **Machine-verified (conservation form)** | `ampere_integral` — QLF_MaxwellCurl.lean |

The homogeneous equation (∇·B = 0) is purely algebraic; ∇·E = ρ/ε₀ is the discrete gauge-imbalance count. The **curl laws are now anchored on the time-indexed event sequence** ([`QLF_MaxwellCurl.lean`](lean/QLF_MaxwellCurl.lean), issue #93): the closure process behind the Heaviside curl form is **flux-conservation telescoping** — Faraday's boundary EMF telescopes to minus the net magnetic-flux change (`faraday_integral`, the Stokes/integral form), so a closed magnetic cycle induces zero net EMF (`faraday_closed_cycle`, Faraday as a ZFA closure); Ampère–Maxwell is the dual with an enclosed source current plus the displacement current (`ampere_integral`). The full 3-D vector `∇×` with Stokes' theorem on the synthesized metric is the continuum rendering of this discrete conservation.

---

## The continuum bridge — Brownian motion renders the curl/wave operators

The one thing the [`QLF_MaxwellCurl`](lean/QLF_MaxwellCurl.lean) core leaves as "the continuum rendering" — the smooth `∇×` / d'Alembertian `□` on the synthesized metric — is exactly the kind of *lattice‑difference → continuum‑differential* limit that has a **named, settled‑math bridge**: the **random‑walk → Brownian‑motion → continuum‑Laplacian** scaling limit. So Maxwell's continuum face is discharged in the same "verified discrete core + one scrutinized continuum bridge" pattern as the [Millennium](Millennium.md) problems — it is the **field‑theory counterpart** of the Navier–Stokes limit and the [Einstein‑curvature CST limit](Einstein_Equations.md).

**The chain is native and classical:**

1. **Discrete substrate = a random walk.** The closure census is a `±1` walk on `ℤ^p` — a ZFA‑balanced string of length `2n` is a closed walk that returns to origin ([`QLF_CensusBrownian`](lean/QLF_CensusBrownian.lean): `census_is_closed_walk_count`, `returnDensity_eq_sq_1d`). This is the same census whose exact dynamics [`brownian_closures.py`](brownian_closures.py) computes.
2. **Scaling limit = Brownian motion, generator = the Laplacian.** Under the diffusive scaling the census walk converges to `p`‑dimensional **Brownian motion** (Donsker's invariance principle), and the discrete lattice Laplacian converges to the continuum Laplacian `∇²` (settled potential theory). The Planck floor is the UV cutoff, so the walk is discrete *below* it and Brownian *above* — the continuum, one closure at a time ([`Mathematics_From_QLF.md`](Mathematics_From_QLF.md), [`Navier_Stokes_Geometry.md`](Navier_Stokes_Geometry.md) §6b).
3. **Maxwell = built from Laplacians.** In Lorenz gauge Maxwell is `□Aμ = μ₀Jμ`, `□ = (1/c²)∂ₜ² − ∇²` — a wave operator built from the very Laplacian the walk renders. Its Green's function (the photon propagator) **is** the Brownian/heat kernel: **Feynman–Kac** writes the EM propagator as an expectation over Brownian paths. So the continuum `∇×`/`□` of §Faraday/§Ampère is the scaling‑limit rendering of the discrete flux‑telescoping closures, carried by Brownian motion.

**It is the same census→Brownian rendering already used for turbulence.** The photon is the *abelian, gauge‑fold‑free* closure ([`QLF_GaugeUnification`](lean/QLF_GaugeUnification.lean): `em_gauge_abelian` — trivial holonomy, massless long‑range), so its rendered propagator is the massless/Coulombic Brownian kernel — the log‑correlated / GMC substrate that already unifies the census, turbulence, and the Riemann critical line ([`Riemann-Conjecture-Proof.md`](Riemann-Conjecture-Proof.md)). Brownian → Maxwell is not a new mechanism; it is the census→Brownian→continuum limit pointed at the EM sector, with the abelian closure selecting the massless kernel.

**Honest scope.** Like every QLF continuum bridge, this *relocates* the continuum to one named, settled‑math scaling‑limit (Donsker + lattice‑Laplacian convergence + Feynman–Kac) over the verified discrete Maxwell core — it does not eliminate it. What it buys: the EM `∇×`/`□` rendering ceases to be an opaque "continuum rendering" and becomes a specific, classical, discharged‑in‑the‑literature limit, of the same rigor class as `continuum_vorticity_planck_capped` and `benincasa_dowker_limit`. See [`TheContinuum.md`](TheContinuum.md) for the substrate‑as‑regularization thesis this instantiates.

---

## Why This Matters

Standard physics postulates Maxwell's equations. QLF derives them as consequences of:
1. The 8-twist alphabet (the only logical structure needed)
2. ZFA balance (the sole selection principle)
3. Hermitian closure (self-adjointness of physical processes)

No additional constants, fields, or gauge principles are introduced. The constants c, ε₀, μ₀ emerge from the ZFA propagation geometry and the 8-fold orthogonality of the twist algebra.

This places electromagnetism within the same derivational chain as gravity ([Gravity.md](Gravity.md)), spacetime synthesis ([SpaceTime.md](SpaceTime.md)), and the Riemann symmetry condition ([Riemann-Conjecture-Proof.md](Riemann-Conjecture-Proof.md)) — all consequences of ZFA, none postulated separately.

See [Lagrangian_Formulation.md](Lagrangian_Formulation.md) for the variational form (ℒ = 0) that unifies all of these.

See [Conservation.md](Conservation.md) for charge conservation as the gauge-swap (+ ↔ −) symmetry of the 8-twist algebra — Noether's theorem applied to the discrete QLF case.

See also: [Collective_Electrodynamics.md](Collective_Electrodynamics.md) — the photon as a joint emitter-absorber ZFA handshake (transactional, relational, not a projectile); [Delayed_Choice_Eraser.md](Delayed_Choice_Eraser.md) — applies the joint-ZFA reading to the canonical retrocausality-puzzle experiment and dissolves it; [Electricity.md](Electricity.md) — Ohm's law, resistance as ZFA closure latency, current↔B via Ampère, and `R_K = Z₀/2α`, with the curl law `∇×E = −∂B/∂t` realized on the substrate twist field.
