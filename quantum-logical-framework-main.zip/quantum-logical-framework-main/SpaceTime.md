# SpaceTime Dynamics in the Quantum Logical Framework

**Author:** Jim Whitescarver  
**Repository:** [quantum-logical-framework](https://github.com/rchain-community/quantum-logical-framework)

*(Note: This document provides a tutorial on the spatial and gravitational network dynamics of [QLF](README.md). For the foundational derivation of how the clock ticks via gauge folds and Planck action, start with [`Time.md`](Time.md).)*

## The Exhaust of Computation

In standard physics, spacetime is treated as a continuous background manifold where events happen. In the Quantum Logical Framework (QLF), **spacetime is the emergent topological boundary of QuCalc resolving logical closures.** It is not the container of reality; it is the "exhaust" of the universal NAND-DAG computation.

Space and time do not exist at the fundamental level. Reality is composed entirely of binary distinctions (twists) from the 8-twist QuCalc alphabet. `RhoQuCalc` acts as the concurrent operating system that pipes the output of one Zero Free Action (ZFA) closure into the context of another.

This tutorial bridges the theoretical concepts of emergent spacetime with their formal machine-verified proofs and executable Python simulations.

---

## 1. The Substrate: Universality and ZFA

Before spacetime can emerge, the system must guarantee that logical structures can persistently form. 

Every terminating logical computation can be unrolled into a finite, acyclic NAND-delay graph. In QLF, these graphs are built from ZFA closures (e.g., `^+ + v^- = 0`). The `zeno_prune` operation actively destroys any topological string that fails to balance, meaning only logically consistent histories survive to construct reality.

* **Formal Proof:** See [`lean/QLF_Universality.lean`](lean/QLF_Universality.lean). This file contains the machine-verified Lean 4 proof that QLF generates all terminating finitely-encoded logical computations. It proves that any valid system annihilates completely under `full_zeno_prune` and achieves ZFA.
* **Core Engine:** See [`twist_core.py`](twist_core.py) to observe the raw twist operations and ZFA closures in action.
* **Variational physics:** The connection between ZFA closures and the Lagrangian principle S=∫ℒ dΩ — including the continuous limit via `EventSynthesisField → Λ_eff` (SpacetimeDynamics.lean:57) — is formalized in [`Lagrangian_Formulation.md`](Lagrangian_Formulation.md).

## 2. Time as Logical Latency

Time is a discrete resource synthesized by gauge folds. One tick of the universal clock corresponds to the resolution of one logical bit (a single ZFA closure) per unit of Planck action. 

That "one logical bit" is now a theorem, not a placeholder — it **is** the two-valued **spin-½ closure**. A single-valued object carries *no* bit (`binary_kl 1 1 = 0`), while the two-valued spinor `{+I, −I}` carries exactly one (`binary_kl 1 (1/2) = log 2`), the `2π` double-valuedness proven from the explicit rotation matrices — grounding the spinor **Cartan** discovered in 1913 ([`lean/QLF_SpinorInformation.lean`](lean/QLF_SpinorInformation.lean)). So each tick — and the local space *and* time it synthesizes — is one resolved ½-spin closure: *it from bit*, the abstraction (a distinction) realized by the closure, at the per-event cost `ΔF = −log 2`.

The time delay ($\Delta t$) required to resolve an event is inversely proportional to its ZFA degeneracy ($W_{ZFA}$), defined as the number of possible ZFA closures available. 

$$\Delta t \propto \frac{1}{W_{ZFA}}$$

In highly constrained environments (like near massive objects), the Markov blankets limit the number of possible ways to achieve ZFA. As $W_{ZFA}$ decreases, the latency per logical step increases. This is the physical mechanism behind **Time Dilation**.

There is no universal clock: **each mass runs its own independent time thread**, and this latency is the tick rate of that one thread. Dilation is therefore never absolute — it is the *ratio* of one thread's synthesis rate to another's, a point made precise in §4.

* **Formal Proof:** See [`SpacetimeDynamics.lean`](lean/SpacetimeDynamics.lean). This file formally proves `time_dilation_in_constrained_space`, mathematically guaranteeing that logic nodes with lower $W_{ZFA}$ have strictly greater logical latency.
* **Empirical Demo:** Run [`muon_lifetime_demo.py`](muon_lifetime_demo.py). This script demonstrates how particle lifetime depends on the internal logical bit synthesis rate. As velocity shifts the reference frame, the internal synthesis rate drops, matching empirical observations of high-velocity muons living longer in the lab frame.

## 3. Space as Logical Distance

If time is the *delay* in computing ZFA closures, space is the *network* of those closures.

Physical distance is a macro-scale illusion masking **logical distance**.  Two nodes in the QuCalc tree that require millions of intermediate resolutions to interact are "far apart." Nodes sharing a direct logical dependency are "adjacent." 

Constant velocity is simply a continuous shift in logical perspective relative to the ZFA network. Approaching the speed of light ($c$) exhausts the available degrees of freedom for internal ZFA cycles. With no internal cycles, the event rate drops to zero, halting the local experience of time. Faster-than-light travel is strictly forbidden because the engine cannot compute "negative events."

This ZFA network is not a passive backdrop — it is the *uniform ether* against which every thread's motion is measured, and §4 shows why its uniformity is what makes $c$ the same for all observers.

### 3a. Why exactly three spatial dimensions — the graph-rendering necessity

Space being the *network of closures* answers a question usually deferred as an input: **why three
dimensions?** The substrate is a **relational graph** — events are ZFA closures, edges are
closure-reachability (the pre-geometric causal network of [`lean/QLF_ReachableEvent.lean`](lean/QLF_ReachableEvent.lean)).
Space is the **faithful rendering** of that graph, and the rendering dimension is *determined* by a
theorem of graph embedding:

- **Every finite graph embeds in ℝ³ without crossings.** Place the vertices on the moment curve
  `(t, t², t³)`; no four are coplanar, so no two edges cross — for *any* graph, `Kₙ` included.
- **Three is the minimum.** In ℝ² only *planar* graphs embed; `K₅` and `K₃,₃` cannot (Kuratowski).
  One and two dimensions cannot faithfully render an arbitrary relational structure.

So three dimensions is **necessary** (a general closure graph contains non-planar substructure, so
fewer than three would force distinct relations to cross or coincide — spurious identifications, an
incoherent world), **sufficient** (every graph fits in 3D; none needs more), and **selected** (the
minimal faithful rendering is the most economical — the MRE / minimal-description optimum — and the
only *comprehensible* one; more dimensions render nothing 3D cannot, at extra descriptive cost). In
one line:

> **Three is the minimal dimension in which any relational structure can be faithfully and
> comprehensibly rendered at all — so *that there is anything (any rendered world) at all* entails
> three spatial dimensions.**

This is a derivation of `substrate_spatial_dimension = 3`, not an assumption of it. The other QLF
3-signatures — Newton's `1/r²` (Gauss's law in 3D), the nuclear magic numbers, and `α = N = 3²`
([`Magic_numbers.md`](Magic_numbers.md), [`QLF_FineStructureSubstrate`](lean/QLF_FineStructureSubstrate.lean)) —
are then *consequences and cross-checks* of the 3D rendering, not independent posits of it; and the
three fermion generations inherit it (`num_generations = substrate_spatial_dimension = 3`,
[`QLF_Generations`](lean/QLF_Generations.lean)). Because `α = N = 3²` is a consequence of the 3D
rendering, the derived `α = 1/137` is the value of **fully-rendered 3D space** (the IR / `q²→0` anchor),
and its Standard-Model "running" reads as the effective-dimension flow `3→2` toward the UV — see
[**Alpha.md**](Alpha.md), which also proves `α(0)` carries no cosmological-time drift (it is a function
of the rendering dimension alone, `α(d) = 1/(128 + d²)`). **Honest scope:** the embedding theorem is exact; the
premises it rests on — that the substrate *is* a relational graph and space *is* its minimal faithful
rendering — are QLF's own load-bearing ontology (the synthesis claim + `QLF_ReachableEvent`), not
extra assumptions, so this derives 3D *within QLF*, not from nothing external.

The above is the *counting* layer (why the rendering dimension is 3). The *mechanism* layer — how the
pre-geometric pointer-swap dynamics of the substrate becomes sparse operational 3D *for an embedded
observer* — is specified and made falsifiable in [`Pointer_Swap_Fuzz.md`](Pointer_Swap_Fuzz.md): geometry
is built only from swap-orbit invariants, and "sees 3D" gets exact content as swap-graph ball growth
`~ r³`. A first computation ([`pointer_swap_fuzz.py`](pointer_swap_fuzz.py)) finds growth dimension near 3
for the two substrate-natural closure lengths (the minimal 4-twist chiral loop and the length-8
four-complement-pair balanced closure), with the decisive substrate-fixed swap generating set still open.

## 4. The Uniform Ether and Lorentz Invariance

The ZFA network of §3 is more than a relational graph — it is **Einstein's stateless ether**. In his 1920 Leiden address Einstein rehabilitated the ether as something with real physical and metric properties but **no state of motion**: a medium you cannot ride, with no preferred rest frame. The QuCalc substrate is exactly this. It is structured — it supplies the degeneracy $W_{ZFA}$ that sets each thread's tick rate — yet statistically **homogeneous**: away from mass clusters, every node of the network offers the same $W_{ZFA}$. Because the ether has no mechanical state, no thread can measure absolute motion through it.

This homogeneity is what ties the two dilations of §2–3 into one mechanism. Both are the *same* effect — fewer ZFA closures synthesized per unit of some *other* thread's clock:

* **Gravitational dilation** (§2, §5): a mass cluster lowers the *local availability* of closures, raising latency $1/W_{ZFA}$ and slowing the thread.
* **Kinematic dilation** (§3): motion spends degrees of freedom on translation, leaving fewer DOF for internal ZFA cycles, so the thread completes fewer closures.

Because the ether is uniform, **no thread is privileged**. Two threads in relative motion each measure the *other* as slow, reciprocally and symmetrically — there is no fact of the matter as to which "really" runs slow, because there is no preferred frame to anchor the claim. That reciprocal symmetry **is** the content of Lorentz invariance. The frame-independence of $c$ then follows: $c$ is the ceiling on local event-synthesis rate (§3), and a *uniform* substrate imposes the *same* ceiling on every thread. Einstein assumed the constancy of $c$; QLF derives it from the homogeneity of the ZFA ether.

> Independent time threads (no shared clock) + a stateless uniform ether (no preferred frame) ⟹ time dilation is reciprocal ⟹ Lorentz invariance is emergent, not postulated.

* **Further Reading:** This is the spatial-network view of the argument developed thread-first in the [`Time.md`](Time.md) section *Time Dilation as Thread Desynchronization* (§4). The two sections are the same claim seen from the time side and the space side.

## 5. Gravity as a Possibilist Gradient

QLF derives gravity strictly from computational probability, avoiding the need for curved spacetime geometry. 

Mass is a dense cluster of localized, stable ZFA closures. These clusters restrict the possibilist space around them, acting as Markov blankets that lower $W_{ZFA}$ for nearby events. Because standard events naturally resolve along the paths of least resistance (highest degeneracy), a particle will statistically drift toward regions where it requires fewer local cycles to resolve its history. 

Gravity is simply the statistical gradient of ZFA resolution latency.

* **Formal Proof:** See the `gravity_is_time_dilation` theorem in [`SpacetimeDynamics.lean`](lean/SpacetimeDynamics.lean). This verifies that a shift in the gravitational gradient strictly implies a shift in time dilation, linking the two phenomena computationally.
* **Empirical Demo:** Run [`SpaceTime.py`](SpaceTime.py). 
  * *Tutorial Step:* When you execute this file, a simulated QuCalc grid is generated with a "massive" ZFA cluster at the center. Watch as the test particle's random walk is statistically biased toward the mass, moving from regions of high $W_{ZFA}$ (empty space) into the high-latency gravity well, perfectly modeling the possibilist gradient descent.

## 6. Universal Expansion (The Cosmological Computation)

The universe is not expanding into an empty void; the QuCalc engine is simply synthesizing more bits.

The total accumulated period of the universe grows with every successful ZFA closure. **The Cosmological Horizon** is the physical boundary reached by the very first synthesized bits of the QuCalc engine. The continuous unrolling of the finite NAND-DAG computation manifests physically as the metric expansion of space.

* **Further Reading:** For the exact mathematical relationship linking the Cosmological Horizon to the Planck Length ($R_H / l_P = T_U / \Delta t_P$), refer back to the Cosmological Clock section in [`Time.md`](Time.md).

## 7. See it live: the Spacetime Constructor

Everything above is one picture when you can turn it in your hands. **[`spacetime_constructor.html`](spacetime_constructor.html)** ([live](https://rchain-community.github.io/quantum-logical-framework/spacetime_constructor.html)) is an interactive 3-D tool where **quantum logic, seen from one observer's perspective, generates a world from nothing** — the first distinction unfolding the closure census. There are **no forces or fields and no action at a distance** — only ZFA closures that **do** close, because in a quantum-logical system things happen **every way possible** and what we see is what happens in the **most ways**. A closure's **frequency *is* that number of ways** (its census multiplicity) — read out as space (*where*), time (*how fast*), and colour (the rate on the spectrum); a reading, never a cause. The background radiation only *enhances* the generation — it sets how much of the churning foam freezes out as real matter.

Heat the background from the CMB toward the Planck temperature and QLF's *logical bang* unfolds on its own — Planck-mass black holes Hawking-cascading into hadrons, cooling into atoms — with **no forces** (latency gradient), **no dice** (the census draws the space), and nothing scripted. Drag the observer and the whole perspective moves with him; dial a frequency band to microscope the spectrum; capture the scene as QuCalc and create your own.

**Full write-up:** [**`Spacetime_Constructor.md`**](Spacetime_Constructor.md).
