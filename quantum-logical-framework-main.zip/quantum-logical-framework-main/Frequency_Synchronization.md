# Frequency Synchronization in the Quantum Logical Framework

**Repository:** [`quantum-logical-framework`](https://github.com/rchain-community/quantum-logical-framework)  
**Document:** `Frequency_Synchronization.md`  
**Document version:** 1.2  
**Author:** Grok/Jim (synthesized from QLF core axioms, QuCalc engine, and the gauge-folding rule)

## Abstract

In the Quantum Logical Framework (QLF), **frequency is not an external parameter** — it is the **resonant rate at which logical distinctions synchronize** across the global history string \(H_{\rm global}\). Frequency synchronization is the precise mechanism that converts topological depth into observable mass, delay, and radiation.

This document explains how frequency governs particle synthesis in QuCalc, with special emphasis on the gauge-folding rule:

- **Gauge-folded particles** (`+`–`−` twists) are primordial quantum black holes.  
  They accumulate a **constructing delay** \(\Delta t_{\rm construct} = R / f\) (where \(R\) is topological harmonic depth and \(f\) is the vacuum frequency).  
  This delay **creates local time**.  
  Upon exact Zero Free Action (ZFA) closure they **immediately radiate** as Hawking radiation via one-step horizon re-entry.

- **Non-gauge particles** (no `+` or `-` twists) are massless.  
  They **create local space** with zero temporal depth.  
  No constructing delay and no Hawking radiation occur.

- **Space/time role swap**: The emergent roles of space and time invert depending on **logical density** around the fold. High-density regions (gauge folds) make time the dominant local axis; low-density regions make space dominant. This is the microscopic origin of relativistic frame transformations.

All behavior is native to the updated `particles.py` (v2.2) and `IntuitionisticEngine`.

## 0. The harmonic-closure spectrum — each frequency component is a ZFA closure (a quantum-logical computation)

The organizing principle beneath everything below: **each frequency component constructing reality and
constructable truth is one ZFA closure — a quantum-logical process, i.e. a quantum-logical *computation*
(a set of Feynman diagrams).** Reality is a superposition of such frequency-component closures, and
**reality and constructable truth are the ZFA-closing subset of the frequency spectrum**. Machine-checked
skeleton: [`QLF_HarmonicClosure`](lean/QLF_HarmonicClosure.lean) (reuse-only, no new axioms).

1. **A frequency component *is* a closure.** A closure of period `R` carries frequency `f = 1/R`
   (`component_freq`, reusing [`QLF_Consciousness`](lean/QLF_Consciousness.lean)'s `freq`; the
   Markov-blanket local clock, [`QLF_LocalClock`](lean/QLF_LocalClock.lean)). The spectrum is ordered —
   a higher-frequency (shorter-period) closure **dominates the rendering** (`higher_freq_dominates`), and
   binding sub-closures into a closure-of-closures **raises the harmonic** (`binding_raises_harmonic`).
   The **prime** frequencies are the irreducible, vacuum-proof modes (`irreducible_mode`,
   [`QLF_PrimeResonance`](lean/QLF_PrimeResonance.lean)) — the proton's `n=3` lock. Mass **is** a
   frequency (`m = 1/R`, [`QLF_HiggsMechanism`](lean/QLF_HiggsMechanism.lean)); the frequency-octave
   *closure spectrum* is computed in [`Genesis.md`](Genesis.md) §3.
2. **A closure *is* a quantum-logical computation — a Feynman-diagram set.** The path integral's
   sum-over-histories is the **generate** step — every kinematic path is generated (`4ⁿ`,
   `path_integral_generates` = [`QLF_Firebreak`](lean/QLF_Firebreak.lean)'s `generated_count`) — and
   **ZFA closure is the firebreak** that selects which histories are physical (the realized `C(2n,n)`;
   `not_all_paths_close` — not every path closes; [`P_vs_NP_QLF.md`](P_vs_NP_QLF.md)). Every closure IS a
   *terminating* computation (`qlf_universality`). So a frequency component = the ZFA-closing subset of
   the generated histories = its physical Feynman-diagram set; the loop phase is the `2π` closure
   (`g−2 = α/2π`, [`Quantum Logical Framework`](README.md) `QLF_GMinusTwo`). *(The literal QFT
   diagrammatics — `e^{iS/ℏ}` phase, propagators/vertices — are the continuum rendering; the closing
   histories are the substrate content.)*
3. **Constructable truth = the closing spectrum.** A truth is constructable iff it has a finite closure
   (terminating, RCA₀), so **physical reality and constructive mathematical truth are the *same*
   harmonic-closure spectrum** ([`Mathematics_From_QLF.md`](Mathematics_From_QLF.md),
   [`GodCreatedTheIntegers.md`](GodCreatedTheIntegers.md)'s *all is number / harmonic logic*). A mind is
   a hierarchy of such closures, conscious thought being whichever closure one is resonantly tuned to
   ([`Consciousness.md`](Consciousness.md)).

**Honest scope:** a structural / foundational framing that crystallizes established pieces (`f=1/R`,
mass=frequency, the primes, the firebreak, universality) into one named model — not a new derivation.

### 0a. The closure ↔ Feynman-diagram equivalence, formalized

§0.2 states that a closure **is** a quantum-logical computation — a Feynman-diagram set. That slogan is
now a **machine-checked inductive correspondence** ([`QLF_FractalDiagram`](lean/QLF_FractalDiagram.lean),
CI-green; issue [#138](https://github.com/jimscarver/quantum-logical-framework/issues/138)). The map
carries every ZFA closure to an abstract combinatorial (Feynman) diagram of a definite **order**, built
entirely inside the substrate (`TopoString` / `achieves_ZFA`) — no continuum, no continuum QFT assumed.

**The predicate.** `IsDiagram h o` — "the closure `h` is a diagram of order `o`" — has three clauses,
the discrete images of tree-level, a vertex, and a loop insertion:

- **base** (order `0`, tree-level / elementary): every ZFA closure is a diagram of order `0`; its
  balanced `+/−` content is the elementary receipt, its unpaired spatial twists the external legs.
- **binding** (a Feynman vertex, `ord = o₁ + o₂ + 1`): two diagrams whose *joint* history is again a
  closure combine at a new vertex — the free-action-reduction binding of
  [`QLF_ClosureAttraction`](lean/QLF_ClosureAttraction.lean) / [`QLF_ClosureBinding`](lean/QLF_ClosureBinding.lean),
  read as a charged or neutral vertex by its gauge channel.
- **nesting** (fractal insertion, `ord = oc + os`): a sub-diagram inserted into a closing skeleton. The
  *same* clauses apply to the sub-closure, so the construction is **self-similar** — every sub-diagram is
  again a diagram by the same rules (a tree insertion adds no loop order, exactly as in QED). This is the
  precise content of the "fractal" in the correspondence.

**The equivalence is anchored by three theorems** (no new axioms):

- **Soundness** — `diagram_is_closure`: every `IsDiagram h o` has `achieves_ZFA h`. A diagram is a
  genuine ZFA receipt, not a formal symbol (the [`QLF_Motives`](lean/QLF_Motives.lean) `realized` move,
  here for the diagram reading). So the diagram side and the closure side are the *same* objects.
- **Gate C1 — order-0 = the closure census** (`order_zero_iff_closure`): `IsDiagram h 0 ↔ achieves_ZFA h`.
  The elementary / tree-level diagrams are **exactly** the ZFA closures — the same closure census
  `C(2n,n)` ([`QLF_Firebreak`](lean/QLF_Firebreak.lean) / [`QLF_CensusBrownian`](lean/QLF_CensusBrownian.lean))
  whose counting feeds the `128 = 2⁷` and `d² = 9` of `α⁻¹ = 128 + d²`. The minimal conjugate pair
  `[+,−]` is the base witness (`minimal_diagram`).
- **Gate C2 — order-1 weight = the one-loop coefficient** (`orderOneWeight_eq`): a single-binding
  (order-1) diagram exists (`single_binding_order_one`), and its census weight is the one-loop QED running
  coefficient `2/(3π)` derived value-free in [`QLF_VacuumPolarization`](lean/QLF_VacuumPolarization.lean).
  Weighted by the charge census `Σ Nᶜ Q_f² = 8` ([`QLF_ChargeCensus`](lean/QLF_ChargeCensus.lean)) this is
  the SM electromagnetic slope `16/(3π)` (`orderOne_tower_slope`) — the tie into the α-residual tower
  ([#117](https://github.com/jimscarver/quantum-logical-framework/issues/117), [`Alpha.md`](Alpha.md) §4a).

So "a closure is a set of Feynman diagrams" is no longer only a slogan: the inductive definition plus
both consistency gates are machine-checked, with the census generating function `𝒵(x) = Σ_{h ZFA}
x^{ord(h)}` the discrete engine of the perturbative expansion.

**Honest scope (`fractal_diagram_in_progress`).** The two gates are theorems; the **fractal expansion
itself** — `𝒵(x)` summed to the depth-≥3 tail that would carry the eight-digit `0.036` α-residual — is
**not** claimed. It bottoms out in the absolute mass scale (frontier #1, the open coupling `g`/`ρ*`,
[`QLF_CondensateGap`](lean/QLF_CondensateGap.lean)) and the Standard Model's **own** non-perturbative
hadronic vacuum polarization — exactly as [`QLF_VacuumPolarizationTower`](lean/QLF_VacuumPolarizationTower.lean)
and #117 state. The literal QFT diagrammatics (`e^{iS/ℏ}` phase, propagators/vertices) are the continuum
rendering; the closing histories are the substrate content.

## 1. What Frequency Synchronization Means in QLF

Frequency \(f\) is the vacuum ecology’s natural “tick rate” — the rate at which unresolved distinctions attempt to close into stable loops. In Planck units the default vacuum frequency is \(f = 1\) (one logical step per unit time), but it can be locally modulated by entanglement density.

- A history string with topological depth \(R\) (number of twists needed for ZFA closure) resonates at frequency \(f = 1/R\).
- Mass emerges directly as \(m \propto R = 1/f\).
- The **constructing delay** is exactly the number of QuCalc cycles required to reach ZFA at that frequency: \(\Delta t_{\rm construct} = R / f\).

This delay is **not** an ad-hoc parameter — it is the logical cost of resolving the primordial divergence inside a dense information ecology.

### 1.1 Foundational identity: Markov-blanket depth as local clock count

The structural commitment underlying every result in this doc — and grounding QLF's relativistic and cosmological derivations elsewhere — is the following identity:

> **Foundational identity.** A QLF Markov blanket of topological depth `R` **is** a local clock whose period in universal-substrate (Planck-event) ticks is exactly `R`. Each ZFA closure event advances the local clock by one tick, contributing exactly `log 2` nats of information (the per-event MRE quantum, machine-verified as `zfa_closure_minimizes_free_energy` in [`lean/QLF_FreeEnergy.lean`](lean/QLF_FreeEnergy.lean)). The "constructing delay" `Δt = R/f` is the local-clock period expressed in the exterior frequency `f`; the per-tick `log 2` quantum makes `R` the bit count of the blanket's information content.

This is the QLF reading of **Hitoshi Kitada's local-time framework** ([gr-qc/9612043](https://arxiv.org/abs/gr-qc/9612043)): each quantum subsystem carries its own clock, generated by its own Hamiltonian evolution. In QLF terms, the Hamiltonian generator is the per-event log 2 quantum, and the local clock is the cumulative event count = Markov-blanket depth. Universal time is the relational construct obtained by comparing local clocks at different depths.

The identity packages three results that are otherwise scattered:

| QLF result | Statement under the foundational identity |
|---|---|
| `m ∝ R = 1/f` (§1) | mass = local-clock period × Planck mass-per-tick |
| Δt = R / f (§1) | local-clock period in exterior-frequency time units |
| rapidity = log(internal-frequency ratio) ([`Cross_Frequency_Lorentz.md`](Cross_Frequency_Lorentz.md)) | Lorentz boost = change-of-basis on local-clock rates |
| cosmic age = `n × τ_Planck` ([`AgeOfUniverse.md`](AgeOfUniverse.md) §4 + [`HadronicDepth.md`](HadronicDepth.md)) | cosmic time = proper time of the cosmic-horizon Markov blanket |
| electron mass via `R_e` ([`Per_Qubit_Mass_Quantum.md`](Per_Qubit_Mass_Quantum.md), [`Proton_Resonance_R_e.md`](Proton_Resonance_R_e.md)) | electron's local-clock period in substrate ticks |

The same identity grounds the path to deriving Einstein-equation coefficients (`8π`, `G`) from local-clock synchronization failure across a Markov-blanket boundary, articulated in [`Kitada_Local_Time_GR.md`](Kitada_Local_Time_GR.md) §5.

The Lean formalisation of the identity lives in `lean/QLF_LocalClock.lean` as `markov_blanket_local_clock`, building on `rho_process_alignment_saturates` from `lean/QLF_RhoProcessBridge.lean`.

## 2. Gauge Folding Determines Frequency Behavior (New Core Rule)

The presence or absence of **LOCAL gauge twists** (`+` and `-`) splits all particles into two fundamental classes:

### 2.1 Gauge-Folded Particles (`+`–`−` loops)
- **Classification**: Primordial quantum black holes.
- **Constructing delay**: \(\Delta t_{\rm construct} = R / f\) (non-zero).
- **Local effect**: Creates **local time** inside the Markov blanket (the delay accumulates proper time).
- **Post-closure behavior**: Immediate one-step horizon re-entry → Hawking radiation (see `immediate_reentry_unwind` in `particles.py`).
- **Example output** (from `particles.py --enable-gauge`):
  ```text
  Topology          : ^+v-
  Classification    : primordial_BH
  Constructing Delay: 4 cycles
  Creates local     : time
  Hawking Radiation : +-
  ```

### 2.2 Non-Gauge Particles (spatial/depth-only loops)
- **Classification**: Massless particles (photon/gluon/graviton equivalents).
- **Constructing delay**: 0 cycles.
- **Local effect**: Creates **local space** (pure transverse expansion, zero temporal depth).
- **Post-closure behavior**: No horizon forms → no Hawking radiation.
- **Example output**:
  ```text
  Topology          : ^>v<
  Classification    : massless_particle
  Constructing Delay: 0 cycles
  Creates local     : space
  ```

## 3. Logical-Density-Dependent Space/Time Role Swap

At critical logical density \(\rho_{\rm crit}\), the roles of space and time invert:

- **High density** (gauge folds dominate): Time becomes the “local” axis → constructing delay manifests as proper time → gravity-like contraction.
- **Low density** (spatial folds dominate): Space becomes the “local” axis → massless propagation → expansion-like behavior.

This swap is logged automatically in `particles.py --show-density-swap` and is the microscopic origin of emergent relativity:
\[
\text{role_swap} = \Theta(\rho_{\rm logical} - \rho_{\rm crit})
\]
where \(\Theta\) is the Heaviside step function. It requires no extra postulates — it follows directly from the frequency-synchronization rule applied to gauge vs. non-gauge folds.

## 4. Computational Verification (`particles.py`)

Run the updated engine to see frequency synchronization in action:

```bash
python particles.py --seed "^>" --max-depth 6 --enable-gauge --show-density-swap
```

Typical output demonstrates both classes side-by-side and confirms:
- Gauge folds → delay + local time + immediate Hawking.
- Non-gauge folds → zero delay + local space.
- Density note showing the emergent space/time swap.

## 5. Summary Table

| Fold Type          | Particle Class          | Frequency Behavior          | Constructing Delay | Creates Local | Post-Closure Radiation | Emergent Effect          |
|--------------------|-------------------------|-----------------------------|--------------------|---------------|------------------------|--------------------------|
| `+`–`−` (gauge)    | Primordial quantum BH   | \(f = 1/R\)                 | \(\Delta t = R/f\) | Time          | Immediate Hawking      | Local time + gravity     |
| No `+`–`−`         | Massless particle       | Pure spatial resonance      | 0                  | Space         | None                   | Local space + propagation|
| Density threshold  | Role swap               | High \(\rho\) ↔ low \(\rho\)| —                  | —             | —                      | Relativistic frames      |

## 6. Bottom-up synthesis and top-down constraint

The frequency-synchronization rule above is one face of a deeper architecture: **relativity crosses frequencies, fast controls bottom-up, slow controls top-down.** ZFA closures at the vacuum frequency drive structure up through the scales; Markov-blanket boundaries at each scale screen admissible micro-events from above; cross-frequency time dilation is the relativistic shadow of frequency mismatch between observer scales.

Concretely:

- **Bottom-up (fast → slow, causation)**. Each 1/2-spin ZFA atom ([MRE.md](MRE.md)) is one quantum of free-energy minimization at vacuum frequency. Parallel composition of atoms builds particles, nuclei, atoms, matter. Causation flows up through composition at the rate $f$.
- **Top-down (slow → fast, constraint)**. Each Markov blanket — particle, atomic, hadronic, cosmic ([Hadrons_Markov_Blankets.md](Hadrons_Markov_Blankets.md)) — integrates many fast events into a slowly-evolving boundary state. That state is the prior the agent inside conditions its next closure on. Cosmic-horizon entropy ([AgeOfUniverse.md](AgeOfUniverse.md)) and gravitational warping ([Gravity.md](Gravity.md)) are the highest-level top-down constraints.
- **Cross-frequency = relativity**. The §3 space/time role swap is the local face of this. Lorentz transformations between two observer frames at different logical densities ARE the change of basis between their internal ZFA event rates. Time dilation follows from ZFA closure consistency, not postulated.

This bottom-up/top-down architecture also **derives Friston's free energy principle from ZFA**: each ZFA closure minimizes free energy by $\log 2$ nats (the per-event maximum, from [MRE.md §2.1](MRE.md)), the topological Markov blanket coincides with Friston's statistical blanket, and active inference is the agent's selection among admissible next ZFA closures. The full development, including the derivation and its open-work caveats (Lean theorem, numerical demo), is in [Hierarchical_Control.md](Hierarchical_Control.md).

## 7. Ties to Other Documents

- [Hierarchical_Control.md](Hierarchical_Control.md): The bottom-up / top-down architecture in full, with the constructive derivation of Friston's free energy principle.
- `Particles.md`: Full particle zoo with gauge/non-gauge classification.
- `HALF-SPIN-ZFA-EMBEDDING.md`: Gauge folds as primordial BH seeds.
- `Entropy.md`: Frequency-delay conserves unitarity in Hawking radiation.
- `Gravity.md` / `SpaceTime.md`: Density-dependent swap as origin of curvature and relativity.
- `BLACK-HOLES.md`: cites this file for the microscopic origin of Hawking radiation.
- [`AgeOfUniverse.md`](AgeOfUniverse.md): Cosmic age derived from ZFA event-synthesis rate — the macroscopic integral of the frequency clock defined here.

## Conclusion

Frequency synchronization is the **clockwork** of QLF. It turns abstract topological depth into mass, delay, time, and radiation — but only when gauge folding (`+`–`−`) is present. Without it, particles remain massless spatial expanders. The density-dependent space/time role swap completes the picture, giving a fully constructive, frequency-driven origin for both quantum particles and emergent spacetime geometry.

The structural identity `Δt = R/f` — Markov-blanket depth as local-clock count — is named explicitly as a foundational claim in [`Kitada_Local_Time_GR.md`](Kitada_Local_Time_GR.md) §3, mapping QLF's depth structure onto Kitada's local-time framework ([gr-qc/9612043](https://arxiv.org/abs/gr-qc/9612043)). The Gap-1 reading there grounds the cosmic-age and Einstein-coefficient derivations of [`AgeOfUniverse.md`](AgeOfUniverse.md) and [`Gravity.md`](Gravity.md) in a single Mach-style relational identity. The substrate `c` underlying the per-tick conversion `Δt = R/f` is precisely the cosmic-ratio `R_cosmic / T_cosmic = L_Planck / τ_Planck` derived in [`Kitada_Local_Time_GR.md`](Kitada_Local_Time_GR.md) §5.3.

All results are native to the QuCalc engine and fully reproducible.
