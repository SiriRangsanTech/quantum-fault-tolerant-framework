#!/usr/bin/env python3
"""
genesis.py  —  ZFA landscape spectrum explorer

Starts from the first distinction (one signed generator pair, the minimal
+g/-g), builds the closure census, treats cycle-order as a frequency octave
hierarchy, and measures the fractal structure of closures at each frequency.

It computes REAL combinatorics and reports MEASURED exponents.  It does not
prove physics.  Every printed result carries an epistemic tag:

    [EXACT]      exact integer/limit combinatorics, machine-checkable
    [MEASURED]   an empirical exponent fitted from the instrument (can vary)
    [STRUCTURAL] an identification / reading, not derived here
    [LEAN]       machine-checked in the Lean layer (module named)
    [OPEN]       conjecture or pending check, stated at full weight

Two DISTINCT fractal signatures are measured and kept separate:
    * spectral (census) exponent  ->  counts conjugate pairs p, slope -p/2
    * swap-graph growth exponent  ->  effective spatial dimension (#62 probe)
Conflating them would be an error; they answer different questions.

Pure standard library (math, cmath, fractions, collections).  No network.
Run:  python3 genesis.py
"""

from __future__ import annotations
import math, cmath
from collections import deque
from functools import lru_cache


# ----------------------------------------------------------------------
# helpers: least-squares slope, tagged printing
# ----------------------------------------------------------------------

def slope(xs, ys):
    """Least-squares slope of ys vs xs."""
    n = len(xs)
    mx = sum(xs) / n
    my = sum(ys) / n
    num = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    den = sum((x - mx) ** 2 for x in xs)
    return num / den if den else float("nan")


def rule(title):
    print("\n" + "=" * 70)
    print(title)
    print("=" * 70)


# ----------------------------------------------------------------------
# 1. THE FIRST DISTINCTION  ->  the binary closure census
#    One conjugate pair (+g, -g).  A length-2n word over {+g,-g} closes
#    iff it is balanced (net-zero ledger).  Generated = 4^n, realized =
#    C(2n,n).  This is the firebreak census; its 1/sqrt(pi n) tail is the
#    census->pi anchor that feeds alpha.
# ----------------------------------------------------------------------

def binary_census(n: int):
    total = 4 ** n                      # 2^(2n) sequences of +/- steps
    realized = math.comb(2 * n, n)      # balanced (closed) ones
    return total, realized, realized / total


# ----------------------------------------------------------------------
# 2. MULTI-PAIR CENSUS  ->  p independent conjugate pairs (candidate axes)
#    A length-L=2m word over 2p generators closes iff every pair balances:
#    a closed L-step walk on the p-dimensional integer lattice.
#    closed_walks(p,m) = C(2m,m) * c_p(m),
#       c_p(m) = sum_{j1+..+jp=m} multinomial(m;j)^2,
#    via  c_p(m) = sum_k C(m,k)^2 * c_{p-1}(m-k),  c_1 = 1.  Exact integers.
#    ratio ~ C * m^{-p/2}: the spectral exponent encodes the pair count.
# ----------------------------------------------------------------------

@lru_cache(maxsize=None)
def c_pair(p: int, m: int) -> int:
    if p == 1:
        return 1
    return sum(math.comb(m, k) ** 2 * c_pair(p - 1, m - k) for k in range(m + 1))


def multipair_census(p: int, m: int):
    total = (2 * p) ** (2 * m)
    realized = math.comb(2 * m, m) * c_pair(p, m)
    return total, realized, realized / total


def spectral_exponent(p: int, m_lo: int, m_hi: int):
    """Fit log(ratio) vs log(m) -> slope ~ -p/2  [MEASURED, converges to EXACT]."""
    ms = list(range(m_lo, m_hi + 1))
    logm = [math.log(m) for m in ms]
    logr = [math.log(multipair_census(p, m)[2]) for m in ms]
    return slope(logm, logr)


# ----------------------------------------------------------------------
# 3. FREQUENCY-OCTAVE HIERARCHY  ->  the closure spectrum
#    Octave j has order n = 2^j.  Closure entropy = log2(#closures) = bits.
#    Energy per closure = log 2 (dF = -log 2).  Equal contribution per
#    octave (constant increment) is the self-similar / scale-invariant
#    signature; a log-periodic residual would signal discrete scale
#    invariance.  We measure both and report honestly.
# ----------------------------------------------------------------------

def octave_spectrum(j_max: int, p: int = 1):
    rows = []
    for j in range(0, j_max + 1):
        n = 2 ** j
        if p == 1:
            _, realized, ratio = binary_census(n)
        else:
            _, realized, ratio = multipair_census(p, n)
        bits = math.log2(realized)
        rows.append((j, n, bits, ratio))
    return rows


def self_similarity(rows):
    """Increment of closure-bits per octave; constant => scale invariant."""
    incr = [rows[k + 1][2] - rows[k][2] for k in range(len(rows) - 1)]
    ratios = [incr[k + 1] / incr[k] for k in range(len(incr) - 1) if incr[k]]
    return incr, ratios


def dft_logperiodic(p: int, n_max: int):
    """
    Remove the smooth Stirling trend from census-bits and DFT the residual
    against index to look for discrete-scale-invariance (log-periodic) power.
    For the pure binary census the residual is tiny; we report the dominant
    non-DC power so 'no signal' is stated rather than assumed.
    """
    ns = list(range(2, n_max + 1))
    resid = []
    for n in ns:
        if p == 1:
            realized = math.comb(2 * n, n)
            smooth = 2 * n - 0.5 * math.log2(math.pi * n)   # C(2n,n) ~ 4^n/sqrt(pi n)
        else:
            realized = multipair_census(p, n)[1]
            smooth = math.log2((2 * p) ** (2 * n)) - (p / 2) * math.log2(math.pi * n)
        resid.append(math.log2(realized) - smooth)
    # de-mean, then O(N^2) DFT magnitude
    mean = sum(resid) / len(resid)
    r = [x - mean for x in resid]
    N = len(r)
    mags = []
    for kf in range(1, N // 2 + 1):
        acc = sum(r[t] * cmath.exp(-2j * math.pi * kf * t / N) for t in range(N))
        mags.append(abs(acc) / N)
    peak = max(mags) if mags else 0.0
    rms = math.sqrt(sum(x * x for x in r) / N)
    return peak, rms


# ----------------------------------------------------------------------
# 4. SWAP-GRAPH GROWTH  ->  the #62 "sees 3D" dimension probe
#    Nodes = arrangements of a multiset (closure-neutral composites).
#    Edge = one adjacent transposition (a pointer swap; ledger-preserving).
#    Ball growth |{v : swap-dist <= r}| ~ r^D gives the effective spatial
#    dimension D.  Whether the 6+2 -> 3-axis structure yields D~3 is the
#    OPEN #62 question; this measures D, it does not assume it.
# ----------------------------------------------------------------------

def multiset_arrangement_count(counts):
    total = sum(counts)
    denom = 1
    for c in counts:
        denom *= math.factorial(c)
    return math.factorial(total) // denom


def swap_neighbors(state):
    out = []
    s = list(state)
    for i in range(len(s) - 1):
        if s[i] != s[i + 1]:
            s[i], s[i + 1] = s[i + 1], s[i]
            out.append(tuple(s))
            s[i], s[i + 1] = s[i + 1], s[i]
    return out


def swap_growth_exponent(counts, cap=60000):
    """
    BFS from the sorted arrangement; fit log(cumulative ball) vs log(radius)
    over the interior range.  Returns (exponent, n_nodes, diameter) or None
    if the configuration space exceeds `cap` nodes.
    """
    n_nodes = multiset_arrangement_count(counts)
    if n_nodes > cap:
        return None
    # sorted start state, e.g. counts=(2,3) -> (0,0,1,1,1)
    start = tuple(sym for sym, c in enumerate(counts) for _ in range(c))
    seen = {start: 0}
    frontier = deque([start])
    level_sizes = {0: 1}
    while frontier:
        v = frontier.popleft()
        d = seen[v]
        for w in swap_neighbors(v):
            if w not in seen:
                seen[w] = d + 1
                level_sizes[d + 1] = level_sizes.get(d + 1, 0) + 1
                frontier.append(w)
    diameter = max(level_sizes)
    # cumulative ball sizes
    radii, balls, run = [], [], 0
    for r in range(0, diameter + 1):
        run += level_sizes.get(r, 0)
        radii.append(r)
        balls.append(run)
    # fit interior 20%-80% of the radius range (avoid origin/saturation)
    lo = max(1, int(0.2 * diameter))
    hi = max(lo + 1, int(0.8 * diameter))
    xs = [math.log(r) for r in radii[lo:hi + 1] if r > 0]
    ys = [math.log(b) for r, b in zip(radii, balls)][lo:hi + 1]
    if len(xs) < 2:
        return None
    return slope(xs, ys), n_nodes, diameter


def swap_dimension_ladder(half_counts, cap=200_000):
    """
    Finite-size ladder for the binary (k,k) swap-graph: measure the ball-growth
    exponent D(k) as the system grows, and test whether it converges.

    Returns (rows, delta_D, lin_slope) where
        rows      = [(k, nodes, diameter, D), ...]
        delta_D   = successive increments D(k+1)-D(k)  [~constant => linear => diverges]
        lin_slope = least-squares slope of D vs k       [>0 and steady => no finite limit]

    The extrapolation, NOT any single finite D, is what bears on #62 -- and here it
    shows the naive ball-growth diverges, so this instrument does not support D=3.
    """
    rows = []
    for k in half_counts:
        res = swap_growth_exponent((k, k), cap=cap)
        if res is None:
            continue
        D, nn, diam = res
        rows.append((k, nn, diam, D))
    ks = [r[0] for r in rows]
    Ds = [r[3] for r in rows]
    delta_D = [Ds[i + 1] - Ds[i] for i in range(len(Ds) - 1)]
    lin_slope = slope(ks, Ds) if len(ks) >= 2 else float("nan")
    return rows, delta_D, lin_slope


# ----------------------------------------------------------------------
# 5. CONSTANTS SECTOR  ->  where census combinatorics meets physics
#    census -> pi  (Wallis; pi ~ 1/(n*ratio^2)),  and  alpha^-1 = 128 + d^2.
#    pi convergence is [EXACT] in the limit; the alpha identification is
#    [STRUCTURAL] (derived in QLF_FineStructureSubstrate / rigidity module),
#    and the 0.036 residual is [OPEN].
# ----------------------------------------------------------------------

def pi_from_census(n_values):
    out = []
    for n in n_values:
        ratio = math.comb(2 * n, n) / 4 ** n
        out.append((n, 1.0 / (n * ratio * ratio)))   # -> pi as n grows
    return out


def alpha_table(d_values):
    out = []
    for d in d_values:
        inv = 128 + d * d
        out.append((d, inv, is_prime(inv)))
    return out


def is_prime(k: int) -> bool:
    if k < 2:
        return False
    i = 2
    while i * i <= k:
        if k % i == 0:
            return False
        i += 1
    return True


def pure_zfa_alpha():
    """
    alpha^-1 from pure ZFA closures, with the residual weighted by a number the
    octave hierarchy MEASURES -- no CODATA (or any measured constant) enters.

      * The residual is bounded by two closed-form census tails (the same
        generating function that already carries pi), both [LEAN]:
            irred = 126 - 16*sqrt(62)       prime / irreducible closures
            total = 512*sqrt(62)/31 - 130   full Dyson-resummed census
        so  137.015874 < alpha^-1 < 137.048130  is EXACT.

      * The point inside is a convex mix  residual = (1-w)*irred + w*total.
        w is NOT hand-set.  The octave hierarchy (sec 3) is *measured* to be
        scale-invariant -- the self-similarity ratio -> 2 with no anomaly and the
        log-periodic DFT power is ~0, i.e. NO preferred octave.  No preferred
        octave => neither tail is favoured => the two enter with equal weight,
        w = 1/2.  That is the octave-measured weight; it is a prediction, and it
        lands *inside* the exact bounds at 137.032.

    Returns a dict of tagged parts (CODATA is compared only by the caller).
    """
    irred = 126 - 16 * math.sqrt(62)          # [LEAN] QLF_AlphaBound irreducible tail
    total = 512 * math.sqrt(62) / 31 - 130    # [LEAN] censusTail_eq (discharged) full tail

    # measure scale-invariance of the octave hierarchy with the sec-3 instruments
    _, ratios = self_similarity(octave_spectrum(12, p=1))
    ssr = ratios[-1]                          # -> 2.0000 : clean doubling, no anomaly
    lp_peak, lp_rms = dft_logperiodic(1, 400) # -> ~0     : no preferred octave

    w = 0.5                                    # forced by scale invariance (no preferred octave)
    residual = (1 - w) * irred + w * total     # = (irred + total)/2, the scale-invariant midpoint
    inv = 128 + 9 + residual                   # 137 + residual
    return dict(irred=irred, total=total, ssr=ssr, lp_peak=lp_peak, lp_rms=lp_rms,
                w=w, residual=residual, inv=inv)


def logperiodic_probe(sectors=((1, 120), (2, 80), (3, 60), (4, 45))):
    """
    Pre-registered discrete-scale-invariance (DSI) probe across census sectors:
    could a log-periodic correction FORCE the residual weight w off the scale-
    invariant 1/2 (sec 5b), moving 137.032 toward CODATA?  Run BEFORE any CODATA
    comparison; w only moves if a sector shows a genuine line first.

    A real log-periodic line needs BOTH (a) a DFT peak that dominates the
    detrended residual (peak/rms >> 1) AND (b) an OSCILLATING approach of the
    self-similarity ratio to 2.  A monotone single-sign approach is just the
    Stirling correction, not DSI.  (The naive 3*rms/sqrt(N) threshold in sec 3
    false-positives -- it shrinks with N -- so peak/rms is the scale-free test.)
    Returns rows (p, peak, rms, peak_over_rms, monotone_bool).
    """
    rows = []
    for p, nmax in sectors:
        peak, rms = dft_logperiodic(p, nmax)
        _, ratios = self_similarity(octave_spectrum(9, p=p))
        dev = [r - 2 for r in ratios[-6:]]
        one_sign = len(set(1 if d > 0 else -1 for d in dev)) == 1
        shrinking = all(abs(dev[i]) >= abs(dev[i + 1]) for i in range(len(dev) - 1))
        rows.append((p, peak, rms, (peak / rms if rms else 0.0), one_sign and shrinking))
    return rows


# ----------------------------------------------------------------------
# 6. PARTICLE MAP  ->  internal structure -> quantum numbers -> mass/m_e
#    Since m = 1/R = frequency (QLF_HiggsMechanism), the frequency hierarchy
#    (sec 3) IS the mass spectrum.  Internal dimensions (sec 4, D>3) are
#    gauge/color, not 3D space.  Every mass is a ratio to the electron.  The
#    proton & pion ratios reuse THIS run's pi (sec 5 census) and 137 (128+d^2);
#    all values are reused from the cited verified Lean modules, not new fits.
# ----------------------------------------------------------------------

def particle_map():
    pi5 = math.pi ** 5             # pi from the closure census (sec 5)
    inv_alpha = 128 + 3 * 3        # 137, from 128 + d^2 at d=3 (sec 5)
    # name, internal structure, quantum numbers, m/m_e (QLF), measured, tag
    return [
        ("electron", "min chiral loop", "L q=-1 gen1",  1.0,           1.0,      "[ref]"),
        ("muon",     "gen-2 lepton",    "L q=-1 gen2",  206.77,        206.768,  "[depth]"),
        ("tau",      "3-phase Koide",   "L q=-1 gen3",  3477.4,        3477.23,  "[Derived]"),
        ("proton",   "3 colors |S3|=6", "B=+1 q=+1",    6 * pi5,       1836.153, "[Derived]"),
        ("pion+-",   "2 quarks |S2|=2", "B=0 q=+-1",    2 * inv_alpha, 273.132,  "[Derived]"),
    ]


# ----------------------------------------------------------------------
# 7. BLACK-HOLE GENESIS  ->  the Compton = Schwarzschild crossing
#    A closure of mass mu (in Planck masses) has reduced Compton radius 1/mu
#    and Schwarzschild radius 2*mu.  They coincide iff mu^2 = 1/2 -- the Planck
#    floor.  Sub-Planck (mu^2<1/2): Compton > Schwarzschild -> the closure is a
#    QUANTUM black hole (a Markov-blanket horizon = a hadron).  Super-Planck: a
#    true (Schwarzschild) black hole.  So the Planck-mass closure IS the
#    black-hole genesis.  The absolute scale comes from THIS framework:
#    ln(M_Planck/m_p) = 14*pi (QLF_AlphaS, b0=7) and m_p/m_e = 6*pi^5.
#    [LEAN] QLF_QuantumBlackHole.compton_eq_schwarzschild_iff ; QLF_PlanckScale
# ----------------------------------------------------------------------

def compton_radius(mu):        # reduced Compton radius, Planck units
    return 1.0 / mu

def schwarzschild_radius(mu):  # Schwarzschild radius, Planck units
    return 2.0 * mu

def bh_crossing_mu():
    """Exact: 1/mu = 2*mu  <=>  mu^2 = 1/2  ->  mu = 1/sqrt(2)."""
    return 0.5 ** 0.5

def planck_mass_over_me():
    """M_Planck / m_e, from this framework's own scale (no external input)."""
    Mpl_over_mp = math.exp(14 * math.pi)     # QLF_AlphaS: ln(M_Pl/m_p)=14*pi (b0=7)
    mp_over_me = 6 * math.pi ** 5            # QLF_LenzMassRatio
    return Mpl_over_mp * mp_over_me

def particle_mu_table():
    Mpl_over_me = planck_mass_over_me()
    rows = [("electron", 1.0), ("muon", 206.77), ("pion+-", 2 * (128 + 9)),
            ("proton", 6 * math.pi ** 5), ("tau", 3477.4)]
    out = []
    for name, m_over_me in rows:
        mu = m_over_me / Mpl_over_me         # mass in Planck masses
        out.append((name, mu, compton_radius(mu), schwarzschild_radius(mu)))
    return out


# ----------------------------------------------------------------------
# report
# ----------------------------------------------------------------------

def main():
    print(__doc__.strip())

    rule("1. THE FIRST DISTINCTION  (binary closure census)")
    print(f"{'n':>3} {'generated 4^n':>16} {'realized C(2n,n)':>18} {'ratio':>12}")
    for n in [1, 2, 3, 4, 6, 8, 12, 16]:
        t, r, q = binary_census(n)
        print(f"{n:>3} {t:>16} {r:>18} {q:>12.6f}")
    print("\n[EXACT] ratio = C(2n,n)/4^n -> 1/sqrt(pi n).  The first distinction's")
    print("        closure fraction already carries pi; this is the alpha anchor.")

    rule("2. MULTI-PAIR CENSUS  (spectral exponent counts conjugate pairs)")
    print(f"{'p (pairs)':>10} {'fitted slope':>14} {'expected -p/2':>16}")
    for p in [1, 2, 3, 4]:
        s = spectral_exponent(p, 6, 40)
        print(f"{p:>10} {s:>14.4f} {(-p/2):>16.4f}")
    print("\n[EXACT] slope -> -p/2: the census fractal exponent IS the pair count.")
    print("[STRUCTURAL] 3 spatial pairs -> slope -3/2 ; the 8-twist/4-pair -> -2.")
    print("[LEAN] anchored at low orders (QLF_CensusWalk): p=1 = the closure census;")
    print("        p=2 = C(2m,m)^2 = the machine-checked pi return density (sumChooseSq_eq_central,")
    print("        census_p2_is_return_density).  General-p + the -p/2 asymptotic = Wallis residual.")

    rule("3. FREQUENCY-OCTAVE HIERARCHY  (closure spectrum, p=1)")
    rows = octave_spectrum(6, p=1)
    print(f"{'octave j':>9} {'n=2^j':>7} {'closure-bits':>14} {'ratio':>12}")
    for j, n, bits, q in rows:
        print(f"{j:>9} {n:>7} {bits:>14.4f} {q:>12.3e}")
    incr, iratios = self_similarity(rows)
    print(f"\nbits increment per octave : {[round(x,3) for x in incr]}")
    print(f"successive increment ratio: {[round(x,4) for x in iratios]}")
    print("[MEASURED] increment ratio -> 2 (each octave doubles n, ~doubles the")
    print("        extensive 2n term): self-similar cascade across frequency.")
    print("[STRUCTURAL] m = 1/R = frequency (QLF_HiggsMechanism, mass_is_gauge_fold_delay):")
    print("        this frequency hierarchy IS the mass spectrum -- frequency determines")
    print("        mass.  The particle assignments referenced to m_e are in sec 6.")
    peak, rms = dft_logperiodic(1, 40)
    print(f"\nlog-periodic residual: peak power={peak:.3e}, rms={rms:.3e}, peak/rms={peak/rms:.3f}")
    verdict = "no significant" if peak / rms < 0.5 else "a candidate"
    print(f"[MEASURED] {verdict} discrete-scale-invariance signal (peak/rms<<1 = no dominant")
    print("        line; the scale-free test, not the N-dependent 3rms/sqrtN).  Multi-pair")
    print("        sectors are probed in 5c -- all null -- so the hierarchy is scale-invariant.")

    rule("4. SWAP-GRAPH GROWTH  (#62 dimension probe: measured, not assumed)")
    print(f"{'multiset':>16} {'#nodes':>9} {'diam':>6} {'growth exponent D':>18}")
    configs = [(6, 6), (8, 8), (10, 10),            # binary balanced
               (3, 3, 3), (4, 4, 4),                # 3 symbol types
               (2, 2, 2, 2), (3, 3, 3, 3),          # 4 symbol types
               (6, 2), (4, 2, 2)]                   # 6+2 flavours
    for cfg in configs:
        res = swap_growth_exponent(cfg)
        if res is None:
            print(f"{str(cfg):>16} {'(too big)':>9}")
            continue
        D, nn, diam = res
        print(f"{str(cfg):>16} {nn:>9} {diam:>6} {D:>18.3f}")
    print("\n[MEASURED] growth exponent D of the pointer-swap configuration space.")
    print("[STRUCTURAL] D>3 = INTERNAL (gauge/color) dimensions, not 3D space (Jim's reading):")
    print("        the EXTERNAL 3D is the receipt quotient (#62, pointer_swap_fuzz.py ~2.94);")
    print("        the excess beyond 3 is the internal color DOF = stronger forces (sec 6).")

    rule("4b. SWAP-GRAPH EXTRAPOLATION  (does D converge? finite-size ladder)")
    rows, dD, lin = swap_dimension_ladder(range(4, 11))
    print(f"{'k (=(k,k))':>10} {'#nodes':>9} {'diam':>6} {'D(k)':>8}")
    for k, nn, diam, D in rows:
        cross = "  > 3" if D > 3 else ""
        print(f"{k:>10} {nn:>9} {diam:>6} {D:>8.4f}{cross}")
    print(f"\nD increments D(k+1)-D(k): {[round(x,3) for x in dD]}")
    print(f"linear slope of D vs k  : {lin:.4f}  (steady & positive)")
    print("[MEASURED] D does NOT converge -- it climbs past 3 and keeps rising")
    print("        (~ k*log2/log k -> infinity).  The '~3 at moderate size' is a CROSSING.")
    print("[STRUCTURAL] NOT a failed 3D probe (Jim's reading): the external 3D is the")
    print("        receipt-quotient (~2.94, pointer_swap_fuzz.py); the growth beyond 3 is")
    print("        the INTERNAL gauge/color structure -- more internal DOF = stronger")
    print("        forces / more binding = heavier (frequency=mass, sec 6).")

    rule("5. CONSTANTS SECTOR  (census meets physics; tagged)")
    print("census -> pi   (pi ~ 1/(n*ratio^2)):")
    for n, est in pi_from_census([10, 100, 1000, 10000, 100000]):
        print(f"    n={n:>7}   pi ~ {est:.6f}   (err {abs(est-math.pi):.2e})")
    print("[EXACT] converges to pi in the limit (Wallis / Stirling).")
    print("\nalpha^-1 = 128 + d^2:")
    for d, inv, pr in alpha_table([1, 2, 3, 4, 5]):
        mark = "  <- 137, prime, elementary" if inv == 137 else ""
        print(f"    d={d}  ->  {inv:>4}   {'prime' if pr else 'composite'}{mark}")
    print("[STRUCTURAL] d=3 substrate-derived (6+2 split); 128=2^7 selectivity.")
    print("[EXACT] the joint holds at exactly d=3 (cross-sector; see rigidity module).")
    print("[OPEN] the 0.036 residual (QED running): bounded exactly in 5b; point open.")

    rule("5b. ALPHA RESIDUAL  (bounds EXACT; weight measured by the octave hierarchy)")
    a = pure_zfa_alpha()
    print(f"irreducible (prime) tail : {a['irred']:.9f}   [LEAN]  alpha^-1 >= {137+a['irred']:.6f}")
    print(f"total (resummed) tail    : {a['total']:.9f}   [LEAN]  alpha^-1 <= {137+a['total']:.6f}")
    print(f"octave self-sim ratio    : {a['ssr']:.6f}   -> 2 (clean doubling, no anomaly)")
    print(f"log-periodic DFT power    : {a['lp_peak']:.3e}   ~0 (NO preferred octave => scale-invariant)")
    print(f"octave-measured weight w  : {a['w']}          [MEASURED] forced by scale invariance")
    print(f"residual r = (1-w)irred+w total : {a['residual']:.9f}   [MEASURED from pure ZFA]")
    print(f"alpha^-1  = 137 + r       : {a['inv']:.6f}   [PREDICTION, pure ZFA]")
    print(f"CODATA 2018 (external)    : 137.035999   [CHECK ONLY]  -> pure ZFA is {a['inv']-137.035999177:+.6f}")
    print("[EXACT] 137.015874 < alpha^-1 < 137.048130 from the same census that gives pi.")
    print("[MEASURED] w=1/2 is not fitted: the octave hierarchy is measured scale-invariant")
    print("        (ratio->2, DFT power ~0), so no octave is preferred and the two tails")
    print("        weigh equally.  The pure-ZFA prediction is 137.032 -- a falsifiable number.")
    print("[OPEN] the residual +0.004 to CODATA: the interval is only 0.032 wide, so many")
    print("        fractions near 0.62 also hit 137.036 -- proximity is NOT proof.  Whether")
    print("        the ~1.5e-3 log-periodic power (here treated as 0) supplies the +0.004 is")
    print("        the open piece; no measured constant is allowed to select w.")

    rule("5c. LOG-PERIODIC PROBE  (can a DSI correction move w off 1/2? measured first)")
    print(f"{'sector':>8} {'DFT peak':>11} {'rms':>11} {'peak/rms':>9}  {'self-sim -> 2':>28}")
    any_line = False
    for p, peak, rms, pr, mono in logperiodic_probe():
        if pr > 1.0 and not mono:
            any_line = True
        tag = "monotone (Stirling, no DSI)" if mono else "OSCILLATING (candidate)"
        print(f"{'p=%d' % p:>8} {peak:>11.3e} {rms:>11.3e} {pr:>9.3f}  {tag:>28}")
    print(f"\n[MEASURED] {'a DSI line APPEARS -- investigate' if any_line else 'NO DSI line in any sector'}:")
    print("        peak/rms ~ 0.3-0.4 (the dominant bin holds only ~10-16% of the variance,")
    print("        no line) and the self-similarity ratio -> 2 monotonically (single-sign,")
    print("        shrinking) -- the Stirling correction, not discrete scale invariance.")
    print("[RESULT] no sector forces delta_w, so the scale-invariant w=1/2 stands and the")
    print("        pure-ZFA prediction remains alpha^-1 = 137.032.  The +0.004 to CODATA is")
    print("        NOT sourced by a census log-periodic mode; it sits in the continuum/running")
    print("        sector QLF brackets by design (Alpha_Residual.md).  This probe is the")
    print("        falsifiable test: a genuine line here (peak/rms>>1, oscillating) would be")
    print("        the ONLY licensed way to move w -- none appears.")

    rule("6. PARTICLE MAP  (frequency=mass; internal structure -> quantum #s -> m/m_e)")
    print("m = 1/R = frequency (QLF_HiggsMechanism): the sec-3 frequency hierarchy IS the")
    print("mass ladder.  Internal dims (sec 4, D>3) = gauge/color, not 3D space.  Every mass")
    print("is a ratio to the electron; proton & pion reuse THIS run's pi and 137 (sec 5).\n")
    print(f"{'particle':>9} {'internal':>16} {'quantum #s':>13} {'m/m_e QLF':>11} {'measured':>10} {'tag':>10}")
    for name, intern, qn, qlf, meas, tag in particle_map():
        print(f"{name:>9} {intern:>16} {qn:>13} {qlf:>11.2f} {meas:>10.2f} {tag:>10}")
    print("\n[Derived]  proton 6*pi^5 = |S3|*pi^5 (3-colour permutation x internal angular,")
    print("           QLF_LenzMassRatio, 0.002%); pion 2/alpha = |S2|/alpha (2 quarks x exposed")
    print("           chirality, QLF_PionMassRatio); tau via Koide Q=2/3 given m_e,m_mu (QLF_Koide).")
    print("[STRUCTURAL] internal dimension = colour charge (Borromean 3, QLF_QuarkStructure);")
    print("           charge in thirds from 3 colours; generations = 3 axis-pairs (= sec-2 p=3).")
    print("[Hypothesis] deeper internal (higher-D) structure = stronger colour binding = heavier;")
    print("           swap-graph symbol-count <-> quark/colour content (falsifiable, untested).")
    print("[DEFEATER] every row shows the measured value; any mismatch falsifies that assignment.")

    rule("7. BLACK-HOLE GENESIS  (Compton = Schwarzschild crossing at the Planck mass)")
    muc = bh_crossing_mu()
    print("[EXACT] reduced Compton radius 1/mu = Schwarzschild radius 2*mu  <=>  mu^2 = 1/2")
    print(f"        crossing at mu = 1/sqrt(2) = {muc:.6f} Planck masses -- the Planck floor.")
    print("[LEAN] QLF_QuantumBlackHole.compton_eq_schwarzschild_iff (mu^2=1/2) +")
    print("       sub_planck_compton_gt_schwarzschild ; QLF_PlanckScale.planck_length_floor.")
    print(f"\n{'particle':>9} {'mu=m/M_Pl':>12} {'Compton 1/mu':>14} {'Schwarz 2mu':>13}  side")
    for name, mu, rc, rs in particle_mu_table():
        side = "quantum BH (Compton side)" if rc > rs else "true BH (Schwarzschild side)"
        print(f"{name:>9} {mu:>12.2e} {rc:>14.2e} {rs:>13.2e}  {side}")
    print("\n[STRUCTURAL] every particle is DEEPLY sub-Planck (mu ~ 1e-20) -> Compton side ->")
    print("        a hadron IS a quantum black hole (QLF_QuantumBlackHole).  A closure crosses")
    print("        to the Schwarzschild side only at mu = 1/sqrt(2): the Planck-mass BLACK-HOLE")
    print("        GENESIS.  Heating the vacuum to the Planck scale (spacetime_constructor.html)")
    print("        drives closures across it -> tiny black holes that Hawking-cascade back to")
    print("        the Compton side as hadrons -- the logical bang (Creation.md 8a).")

    rule("WHAT THIS COMPUTES vs CLAIMS  (misses at full weight)")
    for line in [
        "COMPUTES [EXACT]  : the closure census, the -p/2 spectral exponent,",
        "                    census->pi convergence, the 128+d^2 joint at d=3, and",
        "                    the Compton=Schwarzschild crossing mu^2=1/2 (black-hole genesis).",
        "READS             : frequency=mass (m=1/R), so the octave hierarchy IS the",
        "                    mass spectrum; D>3 = internal gauge/color (external 3D =",
        "                    receipt quotient); particle map to m_e (sec 6).",
        "DERIVED (reused)  : proton 6*pi^5, pion 2/alpha, tau Koide -- ratios to m_e,",
        "                    verified in QLF_LenzMassRatio/PionMassRatio/Koide.",
        "HYPOTHESIS        : swap-graph symbol-count <-> quark/color content; deeper",
        "                    internal structure = stronger binding = heavier (untested).",
        "STILL OPEN        : DSI (none in binary sector); the alpha 0.036 residual; the",
        "                    ABSOLUTE mass scale (needs closure depth + QCD, not census).",
        "NOT A PROOF       : an exploratory instrument.  The Lean layer, not this,",
        "                    is where the verified ratios live.",
    ]:
        print("  " + line)
    print()


if __name__ == "__main__":
    main()
