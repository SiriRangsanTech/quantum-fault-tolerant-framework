# Knot Theory in QLF — Kauffman's formulation and the substrate bridge

## 1. Kauffman's formulation

Lou Kauffman's knot theory was influential in the original QLF realization that the geometry of quantum
systems is knot-theoretic. His formulation is the natural formal partner to QLF because it is itself
*combinatorial and computational* — a state sum over crossing resolutions — rather than analytic.

### 1.1 The bracket polynomial as a state sum

For an unoriented link diagram `L` with crossings, the **Kauffman bracket** `⟨L⟩ ∈ ℤ[A, A⁻¹]` is defined by
three local rules (Kauffman 1987):

1. `⟨○⟩ = 1` (a single unknotted circle);
2. `⟨L ⊔ ○⟩ = δ · ⟨L⟩`, with the loop value `δ = −A² − A⁻²`;
3. `⟨ ⤬ ⟩ = A · ⟨ ≍ ⟩ + A⁻¹ · ⟨ )( ⟩` — each crossing is resolved into its two **smoothings** (the
   `A`-smoothing and the `A⁻¹`-smoothing).

Iterating rule 3 over all `n` crossings expands `⟨L⟩` as a **state sum** over the `2ⁿ` resolutions:

$$\langle L\rangle \;=\; \sum_{\text{states } s} A^{\,\sigma(s)}\, \delta^{\,|s|-1},$$

where `σ(s)` = (#`A`-smoothings − #`A⁻¹`-smoothings) and `|s|` = the number of disjoint loops in state `s`.
This *generate-every-resolution-and-sum* shape is the crux of the QLF connection (§4).

### 1.2 Writhe and the Jones polynomial

For an **oriented** diagram, each crossing has a sign `±1` (right/left-handed), and the **writhe** is
`w(L) = Σ (crossing signs)`. The bracket alone is not an ambient-isotopy invariant, but the
writhe-normalized

$$f(L) \;=\; (-A^{3})^{-w(L)}\,\langle L\rangle$$

is, and the **Jones polynomial** is `V(L)(t) = f(L)` under `A = t^{-1/4}` (Jones 1984, Kauffman 1987). The
writhe is the oriented signed-crossing sum — the same object QLF calls the linking/winding number (§3).

### 1.3 Reidemeister moves: regular vs ambient isotopy

Two diagrams present the same link iff related by planar isotopy and the three **Reidemeister moves**: R1
(a kink / self-crossing), R2 (a poke — two opposite crossings), R3 (a slide). Crucially:

- `⟨L⟩` is invariant under **R2 and R3** but *not* R1 (`⟨kink⟩ = −A^{±3}⟨L⟩`): it is a **regular-isotopy**
  invariant.
- The writhe correction `(−A³)^{−w}` absorbs the R1 factor, so `f(L)` is invariant under **all three** — an
  **ambient-isotopy** invariant.

This regular → ambient step is mirrored exactly in QLF (§3, §4).

### 1.4 Kauffman's wider program: Laws of Form and virtual knots

Kauffman's *state models* grew from Spencer-Brown's **Laws of Form** — the calculus of a single
distinction and its re-entry — and he later introduced **virtual knots** (diagrams with an extra "virtual"
crossing, knots not embeddable in the plane). Both sit under QLF's twist calculus: re-entry is the twist
closing on itself (ZFA closure), and virtual crossings are a candidate reading of non-realizable / gauge
crossings (a forward direction, §5).

## 2. The QLF ↔ Kauffman dictionary

QLF's substrate and Kauffman's formulation line up object-for-object:

| Kauffman's formulation | QLF substrate |
|---|---|
| link diagram | an embedded ZFA closure ([`HALF-SPIN-ZFA-EMBEDDING.md`](HALF-SPIN-ZFA-EMBEDDING.md) §3b) |
| a crossing | an oriented meeting of twist strands |
| the two smoothings of a crossing | the two twist resolutions the firebreak generates |
| state sum `⟨L⟩ = Σ_s A^{σ(s)} δ^{|s|−1}` | the generate-then-close firebreak ([`QLF_Firebreak`](lean/QLF_Firebreak.lean): `4ⁿ` generated, closures selected) |
| loop value `δ` per closed loop | the ZFA loop-closure weight |
| oriented crossing sign (`±1`) | `signTriple` = the oriented Levi-Civita symbol ([`QLF_ReidemeisterLinking`](lean/QLF_ReidemeisterLinking.lean)) |
| writhe `w(L) = Σ signs` | the signed crossing sum `baryonNumber` / `crossingSum` (linking) |
| bracket regular-isotopy (R2, R3) | the crossing-sign algebra: `crossing_R2_cancel`, permutation-invariance |
| writhe correction → ambient (R1) | R1 self-crossing handling ([`QLF_LinkDiagram`](lean/QLF_LinkDiagram.lean)) |
| Jones polynomial `V(L)` | the ambient-isotopy substrate invariant (linking level proven; full bracket proposed) |
| Reidemeister moves R1/R2/R3 | `linking_r1_invariant` / `linking_r2_invariant` / `linking_r3_invariant` |
| Laws of Form re-entry | the twist closing on itself (ZFA closure) |

## 3. The verified substrate footing (the Lean ladder)

QLF's linking invariant and its Reidemeister invariance are machine-verified, in three rungs:

1. **The invariant** — [`QLF_KnotInvariant`](lean/QLF_KnotInvariant.lean) (reuse-only): the linking number
   `linkingNumber = baryonNumber` (a signed 3-axis linking), orientation-odd, **mirror-negating**
   (`mirror_reverses_linking`, the chiral Jones signature); and the **baryon is a Borromean / Brunnian
   3-link** (`borromean_remove_one_unlinks`, `brunnian_needs_all_three` — remove any one colour and it
   unlinks), over [`QLF_BaryonWinding`](lean/QLF_BaryonWinding.lean) / [`QLF_QuarkStructure`](lean/QLF_QuarkStructure.lean).
2. **Regular isotopy** — [`QLF_ReidemeisterLinking`](lean/QLF_ReidemeisterLinking.lean): the crossing sign is
   the **oriented Levi-Civita symbol** (`crossing_cyclic`, `crossing_transpose`, `crossing_self_zero` = R1
   self-crossings don't link, `crossing_R2_cancel` = R2 opposite crossings cancel), plus mirror oddness and
   the ≤2-axis / gauge-kink invariances. This is exactly Kauffman's *regular*-isotopy layer (§1.3).
3. **Ambient isotopy** — [`QLF_LinkDiagram`](lean/QLF_LinkDiagram.lean): a **Gauss-code diagram** (`Crossing`
   = two component tags + oriented sign) with the linking number `crossingSum` proven invariant under **all
   three** moves — `linking_r1_invariant` (self-crossing), `linking_r2_invariant` (opposite-sign pair
   cancels), `linking_r3_invariant` (a slide permutes crossings, `List.Perm.sum_eq`); Hopf link
   `crossingSum = 2` (`lk = 1`). Reidemeister's theorem (1927 — R1/R2/R3 generate ambient isotopy) is the
   cited topological input.

So at the **linking-number** level QLF has a genuine ambient-isotopy invariant, verified end to end — the
writhe/linking rung of Kauffman's formulation.

## 4. The bridge — from the firebreak state-sum to the Kauffman bracket

QLF's Millennium method is a *verified discrete core + one named bridge to the continuum* (§6). Here is that
bridge for the knot sector, proposed explicitly — and it is QLF's most favorable one, because the continuum
side is *already rigorous* (Reshetikhin–Turaev).

**The discrete side is already the right shape.** The Kauffman bracket *is* a state sum (§1.1), and QLF's
firebreak *is* literally generate-then-close: `expand_generation` generates every resolution and ZFA closure
selects the loops that close ([`QLF_Firebreak`](lean/QLF_Firebreak.lean)). The per-resolution substrate phase
plays the role of Kauffman's `A`-weight; ZFA loop-closure plays the role of `δ`. **Bracket state sum and
firebreak state sum have the same form:** generate every smoothing, weight it, sum.

**The oriented layer already matches.** Kauffman's writhe `w(L) = Σ signs` is exactly QLF's oriented
signed-crossing sum — `signTriple` the oriented sign, `crossingSum` the sum — and the bracket's regular →
ambient step (writhe normalization) is the same step QLF makes from the windowed `baryonNumber`
(`QLF_ReidemeisterLinking`, regular) to the diagram-level `crossingSum` with full R1/R2/R3
(`QLF_LinkDiagram`, ambient).

**The bridge, discrete side built.** The Kauffman bracket is now formalized *as* a QLF firebreak state-sum
and shown to satisfy the bracket's defining relations — machine-verified in
[`lean/QLF_KauffmanBracket.lean`](lean/QLF_KauffmanBracket.lean):

- `bracket A Ai n loops = Σ_s A^{#A} · Ai^{#B} · δ^{loops−1}` over `resolutions n` — the `2ⁿ` smoothing
  states (`resolutions_length`), which *is* the firebreak generate step;
- **`bracket_skein`** — `⟨D⟩ = A·⟨D_A⟩ + Ai·⟨D_B⟩`, the crossing skein relation, which is *literally* the
  firebreak's generate-then-close recursion (split the state sum on one crossing);
- **`bracket_unknot`** (`⟨○⟩ = 1`) and **`bracket_disjoint_circle`** (`⟨D⊔○⟩ = δ·⟨D⟩`, `δ = −A²−Ai²`).

Because these relations **uniquely determine** the Kauffman bracket, the firebreak state-sum, instantiated
with the planar loop-count, *is* `⟨L⟩`. So the identification is no longer a proposal — its discrete side is
proven:

> **`firebreak_bracket_bridge`.** *(discrete side, proven)* The QLF firebreak state-sum satisfies the
> Kauffman skein/normalization relations, hence equals the Kauffman bracket `⟨L⟩`; its writhe-normalization
> `(−A³)^{−w}⟨L⟩` is the Jones polynomial `V(L)` = the Reshetikhin–Turaev / Chern–Simons invariant.

Unlike `yang_mills_continuum_gap` or `spectral_hilbert_polya`, **the continuum side here is already
discharged** (RT via quantum groups; Atiyah's functorial-TQFT axioms). QLF supplies the discrete state-sum;
RT holds up the continuum end.

**The bracket computes named knots.** The loop-count is no longer only cited: for the family of **2-strand
torus links** `T(2,n)` (closures of `σ₁ⁿ`), a concrete loop-count is *computed* from the **Temperley–Lieb**
planar calculus ([`lean/QLF_TorusBracket.lean`](lean/QLF_TorusBracket.lean)): `tlReduce` runs 2-strand TL
composition (`e·e` forms a loop) and Markov closure (`1↦2`, `e↦1`) to give `torusLoops`, the genuine planar
loop count of each smoothing state. Feeding it to `bracket` reproduces the **literature Kauffman brackets**:

| named link | `= T(2,n)` | `bracket` (over a field, `Ai = A⁻¹`) |
|---|---|---|
| kinked unknot | `T(2,1)` | `−A³` (regular-isotopy R1 value, *not* `1`) — `bracket_unknot_kink` |
| **Hopf link** | `T(2,2)` | `−A⁴ − A⁻⁴` — `bracket_hopf` |
| **trefoil** | `T(2,3)` | `−A⁵ − A⁻³ + A⁻⁷` — `bracket_trefoil` |

So the firebreak state-sum, with a real planar loop-count, computes actual named-knot invariants. And the
loop-count is now **general**, not just the 2-strand family: [`lean/QLF_PlanarBracket.lean`](lean/QLF_PlanarBracket.lean)
traces loops for *any* diagram from its **arc code** — a diagram is an arc-matching `arc : ℕ → ℕ` on the
crossing-corners, a state's smoothing an involution, and `planarLoops = cycleCount(arc ∘ smoothing)/2`
(each loop alternates an arc-edge and a smoothing-edge). Instantiated with a knot's arc code it reproduces
the same brackets — Hopf `−A⁴−A⁻⁴` (`bracket_hopf'`), trefoil `−A⁵−A⁻³+A⁻⁷` (`bracket_trefoil'`) —
**cross-validating** against the Temperley–Lieb computation. So `bracket` computes the trefoil's invariant
from the substrate *two independent ways*.

**Honest scope of the bridge.** *Discrete side built and computing; two pieces cited.* Proven: the state-sum
↔ bracket identification via the defining relations (`QLF_KauffmanBracket`), and the bracket *computed* for
named torus links from a genuine planar loop-count (`QLF_TorusBracket`), and computed for arbitrary diagrams
from their arc code by the **general planar loop-tracer** (`QLF_PlanarBracket`) — so the loop-count is no
longer cited at all; it is built. Cited, not proven: (i) the **R2/R3** behavior that makes `⟨L⟩` an
*invariant* under ambient isotopy (Reidemeister, as in `QLF_LinkDiagram`); (ii) the continuum Chern–Simons
rendering, the Witten → RT leg, already rigorous. The remaining QLF-specific work is only *data* (a knot's
arc code) — the loop-count *mechanism* is complete and general.

## 5. The enrichment — embedded-knot geometry

Beyond the linking number, embedding a closure as a spatial knot exposes further invariants, the directions
in which embedded knots *could enrich QLF*:

- **Framing, writhe, and chirality** — refining the proven orientation-odd / mirror-negating signs into a
  full chiral invariant (the hidden-vs-exposed chirality of the proton/pion split, [`Pion_QLF.md`](Pion_QLF.md),
  read geometrically).
- **Knot type as a closure invariant** — the isotopy class of the embedded loop as a label on
  particles/closures, beyond linking.
- **The full Kauffman bracket / Jones polynomial** — via the §4 bridge (the firebreak state-sum).
- **Virtual knots** — Kauffman's virtual crossings as a reading of non-realizable / gauge crossings (§1.4).

## 6. Riding the Witten 1988 precedent

Witten's 1988–89 derivation of the Jones polynomial did something QLF's method depends on being legitimate:
it computed a rigorous invariant from a **physical, non-rigorous** object — the Chern–Simons path integral
`⟨W(K)⟩ = ∫ 𝒟A e^{iS_CS[A]} W_K(A)`, whose measure `𝒟A` has no rigorous definition. It was a *physicist's
heuristic*, not a proof by standard-math criteria. What legitimized it was **what came next**: the answers
were made rigorous by independent mathematics — **Reshetikhin–Turaev** (1991) reconstructed the invariants
from quantum groups / modular tensor categories (the WRT invariants), and **Atiyah** (1988) axiomatized TQFT
into a functorial framework. Witten's Fields Medal (1990) honored the *ideas*; the *rigor* rode in behind
him.

That shape — **a physics engine produces correct invariants through a non-rigorous bridge, later discharged
by independent rigorous means** — is exactly QLF's method: a machine-verified discrete/RCA₀ core **plus one
named bridge** (`firebreak_bracket_bridge` here; `yang_mills_continuum_gap`, `spectral_hilbert_polya`
elsewhere). So Witten 1988 is a citable **precedent that the QLF bridge pattern is honored mathematics**, not
crankery — the Witten → RT arc *is* that pattern, Fields-Medaled.

In the knot sector the ride is stronger than analogy, because QLF is operating **inside Chern–Simons/Jones
territory**: the firebreak *is* a discrete state-sum (the bracket, §4), the linking number and its full
R1/R2/R3 invariance are the discrete cores WRT renders continuous, and here the bridge is **already
discharged** — QLF's **firmest bridge**, unlike Riemann or Yang–Mills.

**The line held (the trap refused):** the precedent legitimizes the *method* and, here, hands QLF an
*already-completed* continuum leg — it does **not** transfer *content*. Witten's theorem is about
Chern–Simons/Jones; it is not a lemma that closes `spectral_hilbert_polya` or `yang_mills_continuum_gap`.
Riding coattails means adopting the licensed division of labor (and inheriting RT's rigor *here*), never
claiming Witten's theorem proves QLF's open bridges — the same discipline as "QLF does not prove Witten's
theorem."

### 6.1 The path integral = all closures = the shared engine

Why the ride is more than borrowed prestige: Witten's object and QLF's are the *same move* — **generate every
possibility, then let a selection principle keep the invariant.**

- **Feynman** sums over *every* path `∑ e^{iS/ℏ}`; **stationary phase** selects the physical one.
- **QLF** generates *every* history (the QuCalc tree, `4ⁿ` paths — [`QLF_Firebreak`](lean/QLF_Firebreak.lean)
  `generated_count`); **ZFA closure is the firebreak** selecting the `C(2n,n)` closing ones
  (`not_all_paths_close`). The `e^{iS/ℏ}` phase cancellation is the *continuum rendering* of that discrete
  firebreak.
- **Witten** integrates over *all* connections `∫ 𝒟A e^{iS_CS} W(K)`; **Chern–Simons topological invariance**
  selects the knot invariant.

In the knot sector these coincide *concretely*: the **Kauffman-bracket state-sum** (§4,
[`QLF_KauffmanBracket`](lean/QLF_KauffmanBracket.lean)) *is* a QLF path integral — generate every `2ⁿ`
smoothing (all paths), the planar loop-closure is the firebreak — and Witten's Chern–Simons path integral is
the continuum rendering of exactly that state-sum, already discharged by RT. So "riding the coattails" is
literal: the same generate-then-select engine, with the continuum leg *finished here*. This is the exemplar for
the five other Millennium bridges ([`Millennium.md`](Millennium.md) §*The engine*), where the same engine runs
with its continuum leg still couched as settled-math-to-discharge.

## 6a. Knot theory *from* QLF — the emergence direction

The sections above run QLF → knot theory: given the substrate, here is the linking number, the bracket, the
named-knot invariants. Read the other way, this is a worked instance of the **mathematics-from-QLF** thesis
([`Mathematics_From_QLF.md`](Mathematics_From_QLF.md) Rung 9): knot theory is not *imported* into QLF, it is
*generated by* the substrate — the same counting-plus-closure that produces ℕ (Rung 1) and the fold group
`μ₄` (Rung 5).

- The **firebreak is the state sum.** The generate step produces every resolution ([`QLF_Firebreak`](lean/QLF_Firebreak.lean));
  ZFA closure counts loops; the Kauffman bracket is *defined* as this state-sum and *proven* to obey the
  Kauffman relations (§4) — it **is** the bracket, not a re-encoding.
- The **Temperley–Lieb algebra is the substrate's planar-closure algebra.** The two smoothings are the two
  ZFA-admissible reconnections; `e·e`-forms-a-loop (the `δ` factor) is TL multiplication; from it the loop
  count of any diagram is *computed* (`QLF_TorusBracket`, `QLF_PlanarBracket`).
- The **Jones polynomial** is the writhe-normalized bracket, so it too is a substrate object; the continuum
  Chern–Simons TQFT is its *rendering* (Witten → RT, §6).

So knot theory joins ℕ, ℤ, `ℤ[i]`, `μ₄`, and su(2)/su(3) on the substrate's emergence ladder — and, unlike
the continuum rungs, it is built **bottom-up in Lean**, not merely told as an origin story: the trefoil's
`⟨L⟩ = −A⁵−A⁻³+A⁻⁷` is computed from the substrate, two independent ways. This is why the knot sector is
QLF's cleanest demonstration of *mathematics from the substrate*: a complete classical theory (bracket, TL,
Jones), generated, with only the continuum leg cited — and that leg already rigorous.

## 7. Laboratory realization — Kauffman–Smalyukh, *Nature Physics* (2025)

**Paper:** [Fusion and fission of particle-like chiral nematic vortex knots](https://www.nature.com/articles/s41567-025-03107-0)
· Authors include Darian Hall, Jung-Shen Benny Tai, **Louis H. Kauffman**, Ivan I. Smalyukh · 15 December 2025.

The paper demonstrates **topologically protected vortex knots** in chiral nematic liquid crystals that
remain stable, undergo controlled **fusion and fission** via electric pulses, conserve topological
invariants (connected sums, band surgeries), and behave particle-like with achiral cores. The QLF alignment:

- **Twist algebra & gauge folds** — the helical medium and achiral vortex cores mirror the 8-twist algebra
  and gauge folds (`+`/`−`); the achiral regions "where twist cannot be defined" are ZFA closures.
- **Fusion / fission as logical operations** — reversible field-driven transformations are physical twist
  operations and ZFA resolutions.
- **Topological protection = logical constraint** — conserved topological invariants are QLF's shared
  logical constraints (the linking/Borromean conservation of §3): knotted structures persist because they
  satisfy global ZFA consistency.
- **Knot theory realized physically** — Kauffman's framework (Reidemeister moves, bracket polynomials,
  virtual knots) finds experimental embodiment; in QLF these knots are manifestations of the underlying
  logical lattice, not analogies.

Real-world laboratory evidence for the topological-logical structures central to QLF: particles as stable
knotted configurations, controlled transformation via external fields, and particle-like behavior emerging
from topological order.

## Honest scope

- **Proven:** the linking invariant and the Borromean/Brunnian baryon
  ([`QLF_KnotInvariant`](lean/QLF_KnotInvariant.lean)); the crossing-sign Levi-Civita algebra + R1/mirror
  ([`QLF_ReidemeisterLinking`](lean/QLF_ReidemeisterLinking.lean)); **full R1/R2/R3 invariance of the linking
  number over a Gauss-code diagram** ([`QLF_LinkDiagram`](lean/QLF_LinkDiagram.lean)) — an ambient-isotopy
  invariant at the crossing-data level.
- **The bridge, discrete side built (§4):** the Kauffman bracket *as* a firebreak state-sum, proven to
  satisfy the bracket's defining relations ([`QLF_KauffmanBracket`](lean/QLF_KauffmanBracket.lean):
  `bracket_skein`, `bracket_unknot`, `bracket_disjoint_circle`) — so the firebreak *is* the bracket; the
  continuum side already discharged by Reshetikhin–Turaev, the loop-count model the one cited piece.
- **Cited, not proven:** Reidemeister's theorem (1927); the continuum Chern–Simons TQFT (Witten 1988–89,
  rigorized by RT). QLF does **not** prove Witten's theorem or itself construct the continuum TQFT.
- **Structural / forward:** framing/writhe/chirality/knot-type as closure invariants; virtual knots.

## Relevant repo files

- [`HALF-SPIN-ZFA-EMBEDDING.md`](HALF-SPIN-ZFA-EMBEDDING.md) §3b — closures embedded as knots/links (the geometry).
- [`lean/QLF_KnotInvariant.lean`](lean/QLF_KnotInvariant.lean) — the linking / Borromean invariants (reuse-only).
- [`lean/QLF_ReidemeisterLinking.lean`](lean/QLF_ReidemeisterLinking.lean) — the crossing-sign algebra + regular isotopy.
- [`lean/QLF_LinkDiagram.lean`](lean/QLF_LinkDiagram.lean) — the Gauss-code diagram + full R1/R2/R3 invariance.
- [`lean/QLF_KauffmanBracket.lean`](lean/QLF_KauffmanBracket.lean) — the Kauffman bracket as a firebreak state-sum (the §4 bridge, discrete side).
- [`lean/QLF_Firebreak.lean`](lean/QLF_Firebreak.lean) / [`QFT_QLF.md`](QFT_QLF.md) — generate-then-close = the state sum (the §4 bridge).
- [`StringTheory.md`](StringTheory.md) — string modes as ZFA histories in the twist algebra.

---

### References
- V. F. R. Jones (1985). *A polynomial invariant for knots via von Neumann algebras.* Bull. AMS 12.
- L. H. Kauffman (1987). *State models and the Jones polynomial.* Topology 26 — the bracket state sum.
- E. Witten (1989). *Quantum Field Theory and the Jones Polynomial.* Comm. Math. Phys. 121 — Chern–Simons TQFT.
- M. Atiyah (1988). *Topological quantum field theories.* Publ. IHÉS 68 — the functorial TQFT axioms.
- N. Reshetikhin & V. Turaev (1991). *Invariants of 3-manifolds via link polynomials and quantum groups.* Invent. Math. 103 — the rigorous discharge of Witten's invariants.
- K. Reidemeister (1927). *Elementare Begründung der Knotentheorie.* Abh. Math. Sem. Hamburg 5 — R1/R2/R3 generate ambient isotopy.
- [Laws of Form – Kauffman](http://homepages.math.uic.edu/~kauffman/Laws.pdf)
- Hall, Tai, Kauffman, Smalyukh et al. (2025). *Fusion and fission of particle-like chiral nematic vortex knots.* Nature Physics.
