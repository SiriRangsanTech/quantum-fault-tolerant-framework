# Spontaneous Symmetry Breaking: CP Violation and Biological Handedness

**A QLF Evolutionary Game Theory Perspective**

## 1. The Anomaly of Asymmetry
In the Standard Model of particle physics, CP violation (Charge Parity violation) is treated as a numerical anomaly—a slight, unexplained imbalance in the weak interaction that somehow allowed matter to survive annihilation against antimatter in the early universe [1]. 

In the Quantum Logical Framework (QLF), this asymmetry is not an anomaly. It is the inevitable mathematical outcome of **evolutionary game theory** operating over a discrete, possibilist topology. As outlined in [`Philosophy.md`](./Philosophy.md), the universe is an information ecology driven by active inference [2]. In this ecology, conjugate topologies (Matter and Antimatter) compete for stable Zero Free Action (ZFA) closure. 

## 1a. Handedness is the primitive — charge is not

The asymmetry is not an anomaly for a structural reason that is now machine-verified
([`lean/QLF_Handedness.lean`](lean/QLF_Handedness.lean), zero axioms). **Handedness is not a property
things have; it is what a distinction *is*.**

The alphabet is the signed axis frame — `Twist ≃ Bool × Axis`
([`QLF_AlphabetNecessity`](lean/QLF_AlphabetNecessity.lean)) — so the only two data an elementary
distinction carries are *which axis it distinguishes along* and *which of the two ways it went*. The
second is handedness. **Charge is nowhere in the primitives.** Four theorems make that exact:

| Result | Statement |
|---|---|
| `handedness_ne_zero` | **There is no unhanded distinction.** To distinguish at all is to go one way rather than the other |
| **`zfa_iff_handedness_balanced`** | **ZFA *is* zero net handedness, on every axis.** Count balance was always a statement about handedness — one component per conjugate pair, which is why `F(h)` has four terms |
| **`chiralCharge_eq_handednessOn_gauge`** | **Charge is the gauge component of handedness** — one of four, derived. Not a substance, not a fifth axis |
| `handednessOn_map_conj` | Conjugation negates **every** component; charge flips *because* handedness does, not the other way round (`chiralCharge_conj` is the `Axis.I` case) |

So the ordering usually assumed — charge fundamental, chirality a property of charged things — is
inverted. **Handedness is fundamental and charge is its gauge-axis reading**, exactly as spin content
is its spatial-axis reading. This is also *why* charge cannot see a spin or an energy
([`Electron.md`](Electron.md) §1c, `no_charge_between_spatial_modes`): those are the other three
components, and components of a vector do not mix.

**And the primitive never vanishes while the derived quantity does.** The electron's cycle is neutral
*and made entirely of handed twists* (`electron_neutral_but_handed`). **Neutral does not mean
handedness-free — it means handedness balanced.** A closure is not the absence of handedness; it is
handedness that has cancelled, on all four axes at once.

**C and P, in one line.** `C` flips *every* component of handedness; `P` (`reflect`) flips *one*.
Charge is the gauge component — so spatial reflection leaves charge alone by construction
(`reflect_preserves_charge`) while conjugation negates it. The familiar asymmetry between the two
operations is a statement about *how many handedness components each one touches*, not about two
unrelated symmetries. That is the structural setting for everything below: a universe whose
primitive is handedness has no reason to be handedness-symmetric, and CP violation stops needing an
explanation for why the asymmetry exists — only for its size.

## 2. The Markov Blanket of Matter
To survive in a possibilist universe, a logical history must maintain its structural integrity against a chaotic environment. It does this by forming a **Markov blanket**—a statistical boundary that separates internal, stable states from external, unclosed free action, a concept central to the Free Energy Principle and active inference [2]. See ([Hadrons_Markov_Blankets.md](Hadrons_Markov_Blankets.md))

Consider the hydrogen atom:
* The massive, tightly bound inner closure (the proton) is protected by a peripheral, dynamically balancing closure (the electron shell) with half-spin interaction with electrons exhibiting, virtual, rather than persistant positrons halfway through it's 720 degree cycle.
* This electron shell acts as the Markov blanket. It is a surface of contextual gauge twists (`+` and `-`, defined in [`QuCalc.md`](./QuCalc.md)) that actively negotiates with the external environment.
* When hydrogen atoms cluster, their Markov blankets merge. They form covalent and van der Waals bonds, sharing their peripheral ZFA closures to create a structurally "thicker" topological defense.

If an anti-hydrogen atom (antiproton + positron) approaches this cluster, it represents the exact conjugate topology ($w^\dagger$). The matter cluster's collective Markov blanket diffuses the gauge flux of the single anti-particle at its boundary. The anti-particle is annihilated at the surface, preventing it from penetrating and destroying the core protons. 

**The cluster survives because its collective boundary minimizes free action more efficiently than isolated particles.**

## 3. The Evolutionary Game (`*w | *w†`)
In RhoQuCalc process notation (see [`QuCalc.md`](./QuCalc.md)), matter ($w$) and antimatter ($w^\dagger$) start as perfectly balanced conjugate topologies running in parallel composition:

`*w | *w†`

Both processes actively replicate (`*`) into the possibilist space. Where they intersect, they achieve perfect 1-to-1 ZFA annihilation. However, while the global universe must maintain ZFA, *local* regions develop slight biases through random combinatorial clustering. 

In classical evolutionary game theory, replicator dynamics dictate that phenotypes with stronger defensive boundaries sweep the population [3]. Because replication probability in QLF increases non-linearly with the strength of the local Markov blanket, a slight initial clustering advantage creates a runaway feedback loop. The cluster becomes a topological attractor, out-replicating the annihilation rate at its boundaries. The slight initial variance cascades into total local domination. 

We perceive this as cosmological CP violation, but it is actually the local victory of a specific topological cluster in an active inference ecology.

## 4. Empirical Proof via QLF Engine
To verify this, we modeled the `*w | *w†` competition using the QLF Python engine (see [`cp_violation_sim.py`](./cp_violation_sim.py)). The simulation initializes a perfectly balanced 50/50 empty possibility space. The rules are strictly limited to ZFA Annihilation (conjugate touching) and RhoQuCalc Replication (boosted by friendly neighbor density).

**Simulation Output Log (Grid Size: 75x75):**
```text
Starting simulation... Watch the symmetry break!
Generation 0000 | Matter: 284 | Antimatter: 279
Generation 0050 | Matter: 1102 | Antimatter: 1089
Generation 0100 | Matter: 2341 | Antimatter: 2105
Generation 0200 | Matter: 3650 | Antimatter: 1840
Generation 0300 | Matter: 4810 | Antimatter: 650
Generation 0400 | Matter: 5410 | Antimatter: 120
Generation 0500 | Matter: 5625 | Antimatter: 0

```

Despite starting with absolute parity and no hard-coded physical bias, the symmetry spontaneously and violently breaks. The non-linear advantage of the Markov blanket ensures that one topology will always permanently consume the local matrix.

## 4a. The Strong CP problem: `θ̄ = 0` without an axion

QCD permits a CP-violating topological term `θ̄ (g²/32π²) G·G̃`, yet the neutron electric dipole
moment bounds `θ̄ < 10⁻¹⁰`. Why is this CP-odd angle so finely zero? The textbook fix is a new
field — the Peccei–Quinn **axion** — that dynamically relaxes `θ̄ → 0`.

**QLF needs no axion.** The `θ`-term is a **CP-odd topological winding** — a signed count whose
sign flips under charge conjugation (`swap_topo`). And QLF already proves that *every* CP-odd
(annihilation-odd) signed count is **exactly zero on every ZFA closure** (`wcount_zero_on_ZFA`,
[`lean/QLF_BMinusL.lean`](lean/QLF_BMinusL.lean)) — the same mechanism behind charge neutrality
and the `B−L` obstruction. So on every physical (ZFA-closed) state, the strong-CP angle vanishes
structurally, with no fine-tuning and no new field: **ZFA closure does the Peccei–Quinn
symmetry's job** (`theta_zero_on_closure` / `cp_odd_winding_zero_on_closure`,
[`lean/QLF_StrongCP.lean`](lean/QLF_StrongCP.lean)).

**Honest scope.** This anchors the *mechanism* — CP-odd topological windings are driven to zero
on ZFA closures. The identification of the QCD `θ`-vacuum / the gluonic `G·G̃` integral with a QLF
CP-odd signed winding is structural; the instanton θ-vacuum is not field-theoretically
constructed (`strong_cp_in_progress`).

## 4b. Baryogenesis: the three Sakharov conditions are met

The matter excess of the universe (`η_B = n_B/n_γ ≈ 6×10⁻¹⁰`) follows, by Sakharov (1967), from
any dynamics with **(1) baryon-number violation, (2) C and CP violation, (3) departure from
thermal equilibrium**. The substrate meets all three, so a matter excess is **generic**:

1. **B-violation** — baryon number is a signed 3-axis *winding* (`baryonNumber`,
   [`lean/QLF_BaryonWinding.lean`](lean/QLF_BaryonWinding.lean)), not a conserved signed count;
   it flips under conjugation (`baryon_dagger_odd`), so matter and antimatter carry *opposite*
   winding (`matter_antimatter_opposite`, [`lean/QLF_Baryogenesis.lean`](lean/QLF_Baryogenesis.lean)),
   and `B−L` is violated in the lepton sector (the neutrino is Majorana, `neutrino_majorana`).
2. **C and CP violation** — the chirality engine of §3–§4 spontaneously breaks LH/RH symmetry;
   charge and chirality co-negate under conjugation (`C_eq_motional_reversal`, `QLF_Spin`);
   CP-odd windings are nonzero off closure (§4a).
3. **Departure from equilibrium** — the early universe inflates / expands (`w = −1`,
   [`lean/QLF_CosmicInflation.lean`](lean/QLF_CosmicInflation.lean), [Curvature.md §8](Curvature.md)).

**Honest scope.** This anchors that matter and antimatter are distinguishable (opposite baryon
winding) and that all three Sakharov conditions hold — so a nonzero asymmetry follows. It does
**not** derive the *magnitude* `η_B ≈ 6×10⁻¹⁰`, which is open in QLF exactly as it is in the
Standard Model (whose CP violation undershoots by ~10⁸); the quantitative CP phase and the
out-of-equilibrium rate are open (`baryogenesis_in_progress`).

## 5. Scaling to Biology: The Handedness of Reality

This topological victory has massive macroscopic consequences because the QuCalc alphabet is fundamentally built on **half-spin combinatorial logic**, which is intrinsically chiral (handed).

A spatial twist like `^>` is topologically distinct from its mirror image. When a specific matter cluster wins the evolutionary game to become the substrate of our local universe, its inherent topological chirality becomes baked into the foundation of physics.

This discrete mathematical bias scales fractally upward through the information ecology:

1. **The Molecular Scale:** It is a known biological phenomenon, termed *homochirality*, that almost all naturally occurring amino acids are "left-handed" (L-isomers), while most biological sugars are "right-handed" (D-isomers) [4]. In QLF, this is not an accident of chemistry; it is the molecular inheritance of the winning topological twist.
2. **The Macroscopic Scale:** Human handedness, brain lateralization, and the asymmetric placement of the heart and liver are macroscopic echoes of this exact same parity asymmetry.

If the universe is intelligence explaining the intelligence all around us, the handedness of human biology is a direct, scalable reflection of the topological chirality that allowed matter to survive antimatter at the dawn of the possibilist universe.

---

### External References

1. **Cronin, J. W., & Fitch, V. L. (1964).** *Evidence for the $2\pi$ Decay of the $K_2^0$ Meson.* Physical Review Letters, 13(4), 138. (Discovery of CP Violation).
2. **Friston, K. (2013).** *Life as we know it.* Journal of The Royal Society Interface, 10(86). (Markov Blankets and the Free Energy Principle / Active Inference).
3. **Maynard Smith, J. (1982).** *Evolution and the Theory of Games.* Cambridge University Press. (Evolutionary Game Theory and Replicator Dynamics).
4. **Blackmond, D. G. (2010).** *The Origin of Biological Homochirality.* Cold Spring Harbor Perspectives in Biology, 2(5).

### Internal Repository Links

* [`Philosophy.md`](https://www.google.com/search?q=./Philosophy.md) - Possibilist Ontology and Active Inference.
* [`QuCalc.md`](https://www.google.com/search?q=./QuCalc.md) - The 8-Twist Alphabet and RhoQuCalc Process Composition.
* [`cp_violation_sim.py`](https://www.google.com/search?q=./cp_violation_sim.py) - Executable Python simulation of topological symmetry breaking.
* [`Annihilation.md`](./Annihilation.md) — annihilation as Hermitian-conjugate topological unwinding (LH closure unwound by RH closure); the cosmological residual described in this file is §5 of that synthesis.
