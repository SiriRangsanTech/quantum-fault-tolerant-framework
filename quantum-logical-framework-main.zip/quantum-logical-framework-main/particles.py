"""
particles.py
Quantum Logical Framework (QLF) – Particles as Primordial Quantum Black Holes

Updated to match the current QuCalc / RhoQuCalc architecture while preserving
the primordial-black-hole interpretation.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any

from qucalc_engine import (
    PossibilistEngine,
    compute_imbalance,
    hermitian_conjugate,
    is_zfa_closed,
)

try:
    from rho_transpiler import execute_rho
except Exception:
    execute_rho = None


@dataclass
class VacuumEcology:
    baseline_density: float = 0.0
    resolved_histories: List[str] = field(default_factory=list)

    def absorb(self, closed_history: str) -> None:
        self.baseline_density += 1.0
        self.resolved_histories.append(closed_history)


@dataclass
class ParticleRecord:
    label: str
    prefix: str
    closure_name: Optional[str]
    combined_history: Optional[str]
    shortest_closure: Optional[str]
    final_history: Optional[str]
    is_zfa: bool
    imbalance: Optional[tuple]
    hermitian: Optional[str]
    interpretation: str
    depth: Optional[int] = None
    constituents: str = ""


class PrimordialBlackHoleParticle:
    """Interpret a particle as a dense knot of unresolved free action."""

    def __init__(
        self,
        prefix: str,
        label: str = "particle",
        closure_name: Optional[str] = None,
        engine: Optional[PossibilistEngine] = None,
        constituents: str = "",
    ) -> None:
        self.prefix = prefix
        self.label = label
        self.closure_name = closure_name
        self.engine = engine or PossibilistEngine()
        self.constituents = constituents

    def resolve(self) -> ParticleRecord:
        combined_history: Optional[str] = None
        shortest_closure: Optional[str] = None
        final_history: Optional[str] = None

        if self.closure_name:
            combined_history = self.engine.ApplyZfa(self.prefix, self.closure_name)

        if combined_history and is_zfa_closed(combined_history):
            final_history = combined_history
        elif combined_history:
            shortest_closure = self.engine.core_engine.find_zfa(combined_history)
            final_history = shortest_closure
        else:
            shortest_closure = self.engine.core_engine.find_zfa(self.prefix)
            final_history = shortest_closure

        is_closed = bool(final_history and is_zfa_closed(final_history))
        imbalance = compute_imbalance(final_history) if final_history else None
        hermitian = hermitian_conjugate(final_history) if final_history else None
        depth = len(final_history) // 2 if final_history else None  # Hermitian-pair fold depth

        if is_closed:
            interpretation = (
                "Primordial quantum black hole successfully gauge-folded into "
                "a stable ZFA particle closure."
            )
        else:
            interpretation = (
                "Candidate remains unresolved free action; no admissible closure "
                "was found within the current engine constraints."
            )

        return ParticleRecord(
            label=self.label,
            prefix=self.prefix,
            closure_name=self.closure_name,
            combined_history=combined_history,
            shortest_closure=shortest_closure,
            final_history=final_history,
            is_zfa=is_closed,
            imbalance=imbalance,
            hermitian=hermitian,
            interpretation=interpretation,
            depth=depth,
            constituents=self.constituents,
        )


# --- constituents (fundamental fluxoids: ONE ZFA loop = minimum action) ---
PARTICLE_LIBRARY: Dict[str, Dict[str, str]] = {
    "electron": {
        "prefix": "^<v>",
        "closure_name": "",
        "note": "The fundamental fluxoid: one CCW 2pi spatial loop = minimum action.",
        "constituents": "one fluxoid (^<v>)",
    },
    "positron": {
        "prefix": "^>v<",
        "closure_name": "",
        "note": "The electron's Hermitian conjugate (CW fluxoid).",
        "constituents": "one fluxoid (^>v<)",
    },
    "photon": {
        "prefix": "+-",
        "closure_name": "",
        "note": "The minimal gauge loop — the gauge quantum.",
        "constituents": "one gauge loop (+-)",
    },
    # --- the depth progression: neutrino -> positronium -> muonium -> atom ---
    # Each bound state is a joint ZFA closure; each step adds a new direction
    # (a qubit), so the fold depth strictly increases down the ladder.
    "neutrino": {
        "prefix": "^+v-",
        "closure_name": "",
        "note": "Gauge-dominant single loop: spin (^v) + gauge (+-), no <> spatial "
                "width — the 'ghost'. The shallowest rung.",
        "constituents": "one self-closing loop (gauge axis)",
    },
    "positronium": {
        "prefix": "^<v>^>v<",
        "closure_name": "",
        "note": "Symmetric minimal joint closure: electron ++ positron. Mass 2 m_e.",
        "constituents": "electron ^<v> ++ positron ^>v< (spatial square)",
    },
    "muonium": {
        "prefix": "^<v>^>v</\\",
        "closure_name": "",
        "note": "Adds the diagonal /\\ fold — a deeper (antimuon) partner. Mass m_e + m_mu.",
        "constituents": "electron ++ antimuon (+ diagonal axis)",
    },
    "atom": {
        "prefix": "^<v>^>v</\\+-",
        "closure_name": "",
        "note": "Adds the gauge +- fold — the deepest (proton) partner: hydrogen. Mass m_e + m_p.",
        "constituents": "electron ++ proton (+ diagonal + gauge axes)",
    },
}

# The depth ladder shown by default (--particle all): bound states of growing depth.
PROGRESSION: List[str] = ["neutrino", "positronium", "muonium", "atom"]


class IntuitionisticEngine:
    """ZFA-based intuitionistic synthesis engine for particle interactions and fusion."""

    def __init__(self) -> None:
        self._possibilist = PossibilistEngine()
        self.vacuum_frequency: float = 1.0

    def synthesize_proof(
        self,
        seed: str,
        max_depth: int = 12,
        environment_block: bool = False,
        enable_gauge: bool = True,
    ) -> Optional[tuple]:
        """Find a ZFA closure for seed. Returns (topology, classification) or None."""
        closed = self._possibilist.core_engine.find_zfa(seed)
        if not closed:
            return None
        n = len(closed)
        classification: Dict[str, Any] = {
            "mass": n // 4,
            "type": "fermion" if (n // 4) % 2 == 1 else "boson",
            "delay_cycles": max(1, max_depth // 4),
            "creates_local": enable_gauge and ('+' in closed or '-' in closed),
            "density_note": (
                f"rho={'high (environment blocked)' if environment_block else 'low'}, "
                f"gauge={'enabled' if enable_gauge else 'disabled'}"
            ),
            "hawking_emitted": n > 8,
        }
        return (closed, classification)

    def immediate_reentry_unwind(self, topology: str, frequency: float) -> str:
        """Simulate Hawking-style re-entry emission from a closed topology."""
        fragment = topology[:4] if len(topology) >= 4 else topology
        conjugate = hermitian_conjugate(fragment)
        return f"gamma({conjugate}) @ f={frequency:.2f}"


def resolve_rho_process(rho_code: str) -> Dict[str, Any]:
    if execute_rho is None:
        return {
            "status": "unavailable",
            "reason": "rho_transpiler.execute_rho could not be imported",
        }
    return execute_rho(rho_code)


def print_particle_record(record: ParticleRecord, verbose: bool = False) -> None:
    print(f"\n=== {record.label.upper()} ===")
    print(f"open prefix         : {record.prefix}")
    if record.constituents:
        print(f"constituents        : {record.constituents}")
    if record.closure_name:
        print(f"catalog closure     : {record.closure_name}")
    if record.combined_history is not None:
        print(f"ApplyZfa result     : {record.combined_history}")
    if record.shortest_closure is not None:
        print(f"engine closure      : {record.shortest_closure}")
    print(f"final history       : {record.final_history}")
    print(f"fold depth (pairs)  : {record.depth}")
    print(f"ZFA closed          : {record.is_zfa}")
    print(f"hermitian conjugate : {record.hermitian}")
    print(f"interpretation      : {record.interpretation}")

    if verbose:
        print(f"imbalance tuple     : {record.imbalance}")


def print_catalog(engine: PossibilistEngine) -> None:
    print("Registered ZFA closures:")
    for name in sorted(engine.catalog._catalog.keys()):
        print(f"  - {name}: {engine.catalog.get_by_name(name)}")


def run_demo(args: argparse.Namespace) -> None:
    engine = PossibilistEngine()
    vacuum = VacuumEcology()

    print("============================================================")
    print("QLF PARTICLE ENGINE: PRIMORDIAL QUANTUM BLACK HOLE DEMO")
    print("============================================================")
    print("A particle is treated here as a dense knot of unresolved free")
    print("action that stabilizes only by QuCalc / RhoQuCalc ZFA closure.")
    print("============================================================")

    if args.show_catalog:
        print_catalog(engine)
        print("============================================================")

    if args.rho:
        print(resolve_rho_process(args.rho))
        return

    if args.particle == "all":
        targets = PROGRESSION
    elif args.particle == "constituents":
        targets = ["electron", "positron", "photon"]
    else:
        targets = [args.particle]
    records: List[ParticleRecord] = []

    for name in targets:
        spec = PARTICLE_LIBRARY[name]
        particle = PrimordialBlackHoleParticle(
            prefix=spec["prefix"],
            label=name,
            closure_name=spec["closure_name"] or None,
            engine=engine,
            constituents=spec.get("constituents", ""),
        )
        record = particle.resolve()
        records.append(record)
        if record.final_history and record.is_zfa:
            vacuum.absorb(record.final_history)

    if args.parallel and len(records) > 1:
        parallel_inputs = [r.final_history or r.prefix for r in records]
        print("\nParallel composition:")
        print(engine.parallel(*parallel_inputs))

    if args.replicate and records:
        replicated = engine.replicate(records[0].final_history or records[0].prefix, args.replicate)
        print("\nReplication:")
        print(replicated)

    for record in records:
        print_particle_record(record, verbose=args.verbose)

    if len(records) > 1:
        print("\nDepth progression (each step adds a direction / qubit):")
        for record in records:
            arrow = "->" if record is not records[-1] else "  "
            print(
                f"  {record.label:12} depth={record.depth}  {record.final_history:14} {arrow}"
            )

    print("\nVacuum ecology summary:")
    print(f"  resolved histories : {len(vacuum.resolved_histories)}")
    print(f"  baseline density   : {vacuum.baseline_density}")
    if args.verbose and vacuum.resolved_histories:
        print(f"  absorbed closures  : {vacuum.resolved_histories}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="QLF particles updated for current QuCalc / RhoQuCalc support"
    )
    parser.add_argument(
        "--particle",
        choices=[
            "neutrino", "positronium", "muonium", "atom",   # the depth progression
            "electron", "positron", "photon",               # constituents
            "constituents", "all",
        ],
        default="all",
        help="'all' (default) = the depth progression neutrino->positronium->"
             "muonium->atom; 'constituents' = the electron/positron/photon fluxoids.",
    )
    parser.add_argument("--parallel", action="store_true")
    parser.add_argument("--replicate", type=int, default=0)
    parser.add_argument("--show-catalog", action="store_true")
    parser.add_argument("--rho", type=str, default="")
    parser.add_argument("--verbose", action="store_true")
    return parser


if __name__ == "__main__":
    parser = build_parser()
    run_demo(parser.parse_args())
